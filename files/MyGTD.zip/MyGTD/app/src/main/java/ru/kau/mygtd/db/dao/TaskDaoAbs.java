package ru.kau.mygtd.db.dao;

import androidx.room.Dao;
import androidx.room.Transaction;

import java.util.List;

import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.objects.Contekst;
import ru.kau.mygtd.objects.Tag;
import ru.kau.mygtd.objects.Task;
import ru.kau.mygtd.objects.TaskContextJoin;
import ru.kau.mygtd.objects.TaskTagJoin;

@Dao
public abstract class TaskDaoAbs {

    @Transaction
    public static void updateTask(Task task, List<Tag> lstTags, List<Contekst> lstConteksts) {

        // Удаляем тэги и контексты по задаче

        List<TaskTagJoin> lstTaskTagJoin = MyApplication.getDatabase().taskTagJoinDao().getTaskForTag(task.getId());

        for (TaskTagJoin taskTagJoin: lstTaskTagJoin){
            MyApplication.getDatabase().taskTagJoinDao().delete(taskTagJoin);
        }

        MyApplication.getDatabase().taskContextJoinDao().deleteTaskContekst(task.getId());
        MyApplication.getDatabase().taskTagJoinDao().deleteTaskTags(task.getId());



        for (Tag tag: lstTags) {

            TaskTagJoin taskTagJoin = new TaskTagJoin(task.getId(), tag.getId());
            MyApplication.getDatabase().taskTagJoinDao().insert(taskTagJoin);

        }

        for (Contekst contekst: lstConteksts) {

            TaskContextJoin taskContextJoin = new TaskContextJoin(task.getId(), contekst.getId());
            MyApplication.getDatabase().taskContextJoinDao().insert(taskContextJoin);

        }

        MyApplication.getDatabase().taskDao().update(task);


        // ------------------------------------------------------------------


    }

}
