package ru.kau.mygtd.utils;

public interface StringResult {

    void onResult(String result);

}
