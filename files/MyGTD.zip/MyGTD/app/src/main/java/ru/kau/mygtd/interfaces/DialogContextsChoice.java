package ru.kau.mygtd.interfaces;

import java.util.List;

import ru.kau.mygtd.objects.Contekst;

public interface DialogContextsChoice {

    public void getContexts(List<Contekst> conteksts);

}
