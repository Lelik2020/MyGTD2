package ru.kau.mygtd.utils;

import android.view.ViewGroup;

import ru.kau.mygtd.R;

public class Const {

    public final static int LAYOUT_DEFAULT_WIDTH = 35;
    public final static int LAYOUT_DEFAULT_HEIGHT = 35;

    static final public int DEFAULT_LAYOUT_WIDTH = 35;//ViewGroup.LayoutParams.WRAP_CONTENT;
    static final public int DEFAULT_LAYOUT_HEIGHT = 35;//ViewGroup.LayoutParams.WRAP_CONTENT;

    static final public int DEFAULT_ICON_WIDTH = 50;
    static final public int DEFAULT_ICON_HEIGHT = 50;

    static final public int DEFAULT_RTV_WIDTH = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final public int DEFAULT_RTV_HEIGHT = ViewGroup.LayoutParams.WRAP_CONTENT;

    static final public String DEFAULT_RTV_COLOR = "#aa03A9F4";

    static final public int DEFAULT_EXPANDED_ICON = R.drawable.press_down;
    static final public int DEFAULT_COLLAPSE_ICON = R.drawable.not_press;

}
