package ru.kau.mygtd.fragments;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.apg.mobile.roundtextview.RoundTextView;
import com.multilevel.treelist.Node;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import ru.kau.mygtd.R;
import ru.kau.mygtd.adapters.CommentAdapter;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.common.enums.Status;
import ru.kau.mygtd.common.enums.TypeOfTask;
import ru.kau.mygtd.db.dao.TaskDaoAbs;
import ru.kau.mygtd.dialogs.Dialogs;
import ru.kau.mygtd.interfaces.DialogContextsChoice;
import ru.kau.mygtd.interfaces.DialogDateBeginChoice;
import ru.kau.mygtd.interfaces.DialogDateEndChoice;
import ru.kau.mygtd.interfaces.DialogPriorityChoice;
import ru.kau.mygtd.interfaces.DialogProjectChoice;
import ru.kau.mygtd.interfaces.DialogTagsChoice;
import ru.kau.mygtd.interfaces.DialogTargetChoice;
import ru.kau.mygtd.interfaces.DialogTypeOfTaskChoice;
import ru.kau.mygtd.listeners.DefaultListeners;
import ru.kau.mygtd.objects.Contekst;
import ru.kau.mygtd.objects.Information;
import ru.kau.mygtd.objects.Priority;
import ru.kau.mygtd.objects.Project;
import ru.kau.mygtd.objects.Tag;
import ru.kau.mygtd.objects.Target;
import ru.kau.mygtd.objects.Task;
import ru.kau.mygtd.objects.TaskContextJoin;
import ru.kau.mygtd.objects.TaskTagJoin;
import ru.kau.mygtd.objects.TaskTypes;
import ru.kau.mygtd.utils.Const;
import ru.kau.mygtd.utils.Utils;
import ru.kau.mygtd.utils.ViewUtils;

public class AddTaskFragment extends Fragment
        implements DialogProjectChoice, DialogTagsChoice, DialogTargetChoice,
        DialogPriorityChoice, DialogContextsChoice, DialogDateEndChoice,
        DialogDateBeginChoice, DialogTypeOfTaskChoice {

    private TextView projectTitle;
    private TextView typeOfTaskTitle;
    private TextView targetTitle;
    private TextView priorityTitle;
    private TextView contextTitle;
    private TextView dateendTitle;
    private TextView dateBeginTitle;



    private long projectId = 0L;
    private long targetId = 0L;
    private long priorityId = 0L;

    private Target target;
    private Project project;
    private Priority priority;
    private TaskTypes taskTypes;

    private List<Tag> lsttags;
    private List<Contekst> lstConteksts;

    private Date dateEnd;
    private Date dateBegin;

    private TextView addComment;

    private LinearLayout ltasktags;
    private LinearLayout ltaskproject;
    private LinearLayout ltasktype;
    private LinearLayout ltasktarget;
    private LinearLayout ltaskpriority;
    private LinearLayout ltaskcontext;
    private Task taskUpdate = null;


    private String DEFAULT_PROJECT_COLOR = "#fafafa";

    public void bindAdapter(CommentAdapter commentAdapter) {
        DefaultListeners.bindAdapter4(getActivity(), commentAdapter);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.addtask_fragment, null);

        TextView txtTaskTitle = (TextView)rootView.findViewById(R.id.inputTaskTitle);
        TextView txtTaskInfoTitle = (TextView)rootView.findViewById(R.id.inputTaskinfoTitle);

        ltasktags = (LinearLayout) rootView.findViewById(R.id.addtasktags);
        ltaskproject = (LinearLayout) rootView.findViewById(R.id.addtaskproject);
        ltasktype = (LinearLayout) rootView.findViewById(R.id.addtasktype);
        ltasktarget = (LinearLayout) rootView.findViewById(R.id.addtasktarget);
        ltaskpriority = (LinearLayout) rootView.findViewById(R.id.addtaskpriority);
        ltaskcontext = (LinearLayout) rootView.findViewById(R.id.addtaskcontexts);

        //assert getArguments() != null;
        Bundle arguments = getArguments();
        Project parentProject = null;
        //Task task = null;
        if (arguments != null && arguments.containsKey("project")) {
            parentProject = (Project) arguments.getSerializable("project");
        }


        projectTitle = (TextView)rootView.findViewById(R.id.projectTitle);
        //assert parentProject != null;
        if (parentProject != null) {
            projectTitle.setText(parentProject.getTitle());
        }

        typeOfTaskTitle = (TextView)rootView.findViewById(R.id.typeOfTaskTitle);

        targetTitle = (TextView)rootView.findViewById(R.id.targetTitle);

        priorityTitle = (TextView)rootView.findViewById(R.id.priorityTitle);

        contextTitle = (TextView)rootView.findViewById(R.id.contextTitle);

        dateendTitle = (TextView)rootView.findViewById(R.id.dateendTitle);

        dateBeginTitle = (TextView)rootView.findViewById(R.id.datebeginTitle);

        addComment = (TextView) rootView.findViewById(R.id.addComment);

        if (arguments != null && arguments.containsKey("task")) {
            taskUpdate = (Task) arguments.getSerializable("task");
            txtTaskTitle.setText(taskUpdate.getTitle());
            txtTaskInfoTitle.setText(taskUpdate.getDescription());
            projectId = taskUpdate.getProject_id();
            ltaskproject.removeAllViews();
            if (projectId > 0) {
                project = MyApplication.getDatabase().projectDao().getProjectById(projectId);
                //projectTitle.setText((project == null) ? "" : project.getTitle());


                LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.DEFAULT_ICON_WIDTH, Const.DEFAULT_ICON_HEIGHT);
                ImageView iv = new ImageView(getActivity());
                iv.setImageResource(R.drawable.folder);
                iv.setLayoutParams(lParams);

                ltaskproject.addView(iv);

                //lParams = new LinearLayout.LayoutParams(
                //        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                lParams = new LinearLayout.LayoutParams(Const.DEFAULT_RTV_WIDTH, Const.DEFAULT_RTV_HEIGHT);

                RoundTextView rtv1 = new RoundTextView(getActivity());
                //rtv1.setText(lstTask.get(0).getTitle());

                rtv1.setCorner(20);
                rtv1.setPadding(10, 0, 10, 0);
                //rtv1.setCorner(5, 5, 5, 5);
                //rtv1.setBgColor(Color.parseColor(tags.get(j).getColor()));
                rtv1.setTextColor(R.color.black);


                try {
                    rtv1.setBgColor(Color.parseColor(project.getColor()));
                } catch (Exception ex) {
                    rtv1.setBgColor(Color.parseColor(DEFAULT_PROJECT_COLOR));
                }
                //rtv1.setCorner(2, 2, 2, 2);
                //rtv1.setCorner(5);

                rtv1.setText((project == null) ? "" : project.getTitle());

                ltaskproject.addView(rtv1, lParams);

            }

            // Тип задачи

            ltasktype.removeAllViews();
            LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.DEFAULT_ICON_WIDTH, Const.DEFAULT_ICON_HEIGHT);
            ImageView iv = new ImageView(getActivity());
            iv.setImageResource(Utils.getImageResourceTaskType(taskUpdate.getTypeOfTask()));
            iv.setLayoutParams(lParams);

            ltasktype.addView(iv);

            //TextView tv1 = new TextView(getActivity());



            // ----------------------------------------------------------------

            // Собираем тэги

            List<Tag> lstTags = MyApplication.getDatabase().tagDao().getAllByTask(taskUpdate.getId());

            getTags(lstTags);

            // ------------------------------------------------------------------

            //

            List<Contekst> lstConteksts = MyApplication.getDatabase().contextDao().getAllByTask(taskUpdate.getId());

            getContexts(lstConteksts);


            //
            targetId = taskUpdate.getTarget_id();
            target = MyApplication.getDatabase().targetDao().getById(targetId);
            //targetTitle.setText((target == null) ? "" : target.getTitle());

            getTarget(target);



            priorityId = taskUpdate.getPriority_id();
            priority = MyApplication.getDatabase().priorityDao().getById(priorityId);

            getPriority(priority);

            dateBeginTitle.setText(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy HH:mm"), taskUpdate.getDateBegin()));
            dateendTitle.setText(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy HH:mm"), taskUpdate.getDateEnd()));

            RecyclerView recyclerView = (RecyclerView) rootView.findViewById(R.id.comments_recyclerview);

            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            //Log.e("ПОЗИЦИЯ", "ПОЗИЦИЯ");
            //TasksAdapter tasksAdapter = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getAllTasks());



            CommentAdapter commentAdapter = new CommentAdapter(getActivity(), MyApplication.getDatabase().commentDao().getAllOfTask(taskUpdate.getId()));

            bindAdapter(commentAdapter);
            recyclerView.setAdapter(commentAdapter);



            //priorityTitle.setText((priority == null) ? "" : priority.getTitle());
            //lstConteksts =
            //contextTitle
        }


        final ImageView projectchoise = (ImageView) rootView.findViewById(R.id.projectchoise);

        projectchoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.choiseProjectDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        final ImageView projectclear = (ImageView) rootView.findViewById(R.id.projectclear);
        projectclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        final ImageView typesoftaskchoise = (ImageView) rootView.findViewById(R.id.typesoftaskchoise);

        typesoftaskchoise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialogs.showTypesTaskDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //TagDaoAbs.deleteTag(tagName);
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });

            }
        });

        final ImageView tagschoise = (ImageView) rootView.findViewById(R.id.tagschoise);

        tagschoise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialogs.showTagsDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //TagDaoAbs.deleteTag(tagName);
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        final ImageView targetchoise = (ImageView) rootView.findViewById(R.id.targetchoise);

        targetchoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.showTargetsDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        final ImageView prioritychoise = (ImageView) rootView.findViewById(R.id.prioritychoise);

        prioritychoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.showPriorityDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        final ImageView contextschoise = (ImageView) rootView.findViewById(R.id.contextchoise);

        contextschoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.showContextsDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        final ImageView datebeginchoise = (ImageView) rootView.findViewById(R.id.datebeginchoise);

        datebeginchoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.showDateBeginDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        final ImageView dateendchoise = (ImageView) rootView.findViewById(R.id.dateendchoise);

        dateendchoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.showDateEndDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        if (taskUpdate == null) {
            addComment.setVisibility(View.INVISIBLE);
        } else {
            addComment.setVisibility(View.VISIBLE);
        }

        addComment.setOnClickListener(new View.OnClickListener() {
            @Override
                public void onClick(View v) {
                    Dialogs.addCommentDialog(getContext(), null, null, null, null, false);
                }
            });



        Button imgbtnsavetask = (Button) rootView.findViewById(R.id.btnsavetask);
        imgbtnsavetask.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                if (arguments != null && arguments.containsKey("task")) {
                    taskUpdate.setTitle(txtTaskTitle.getText().toString());
                    taskUpdate.setSearchtitle(taskUpdate.getTitle().toUpperCase());
                    taskUpdate.setDescription(txtTaskInfoTitle.getText().toString());
                    taskUpdate.setPriority_id(priorityId);
                    taskUpdate.setTypeOfTask(TypeOfTask.from(taskTypes.getId()));

                    //taskUpdate.setStatus(Status.NEW);
                    taskUpdate.setDateEnd(dateEnd);
                    taskUpdate.setDateEndStr(dateendTitle.getText().toString());
                    taskUpdate.setTarget_id(targetId);
                    //taskUpdate.setDateCreate(new Date());
                    //taskUpdate.setDateCreateStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), taskUpdate.getDateCreate()));
                    taskUpdate.setDateBegin(dateBegin);
                    taskUpdate.setDateBeginStr(dateBeginTitle.getText().toString());

                    TaskDaoAbs.updateTask(taskUpdate, lsttags, lstConteksts);

                } else {
                    Task task = new Task();
                    Task task2;
                    Information information;
                    task.setTitle(txtTaskTitle.getText().toString());
                    task.setSearchtitle(task.getTitle().toUpperCase());
                    task.setDescription(txtTaskInfoTitle.getText().toString());
                    task.setTypeOfTask(TypeOfTask.from(taskTypes.getId()));
                    task.setPriority_id(priorityId);
                    task.setStatus(Status.NEW);
                    task.setDateEnd(dateEnd);
                    task.setDateEndStr(dateendTitle.getText().toString());
                    task.setTarget_id(targetId);
                    task.setDateCreate(new Date());
                    task.setDateCreateStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), task.getDateCreate()));
                    task.setDateBegin(dateBegin);
                    task.setDateBeginStr(dateBeginTitle.getText().toString());

                    Bundle bundle = getArguments();
                    if (bundle != null) {
                        task2 = (Task) bundle.getSerializable("task");
                        if (task2 == null) {

                        } else {
                            task.setParenttask_id(task2.getId());
                        }
                        information = (Information) bundle.getSerializable("information");
                        if (information == null) {

                        } else {
                            task.setInfo_id(information.getId());
                        }

                    }
                    task.setProject_id(projectId);
                    if (task.getTitle().trim().equals("")) {
                        task.setTitle(null);
                    }
                    //MyApplication.getDatabase().beginTransaction();

                    try {

                        long task_id = MyApplication.getDatabase().taskDao().insert(task);


                        List<TaskTagJoin> taskTagJoinList = new ArrayList<TaskTagJoin>();
                        for (Tag tag : lsttags) {

                            TaskTagJoin taskTagJoin = new TaskTagJoin(task_id, tag.getId());
                            taskTagJoinList.add(taskTagJoin);
                        }

                        MyApplication.getDatabase().taskTagJoinDao().insert(taskTagJoinList);

                        List<TaskContextJoin> taskContextJoins = new ArrayList<TaskContextJoin>();
                        for (Contekst contekst : lstConteksts) {

                            TaskContextJoin taskContextJoin = new TaskContextJoin(task_id, contekst.getId());
                            taskContextJoins.add(taskContextJoin);
                        }

                        MyApplication.getDatabase().taskContextJoinDao().insert(taskContextJoins);


                        //Toast.makeText(getActivity(), R.string.taskcreated, Toast.LENGTH_LONG).show();

                        //ViewUtils.viewPositiveToast(getContext(), getLayoutInflater(), String.valueOf(R.string.taskcreated), Toast.LENGTH_SHORT, Gravity.BOTTOM, 0, 0);

                    /*
                    View toastView = getLayoutInflater().inflate(R.layout.activity_toast_custom_view, null);

                    // Initiate the Toast instance.
                    Toast toast = new Toast(getContext());
                    // Set custom view in toast.
                    toast.setView(toastView);
                    toast.setDuration(Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 0, 0);
                    toast.show();

                     */
                    } catch (Exception e) {

                        ViewUtils.viewNegativeToast(getContext(), getLayoutInflater(), String.valueOf(R.string.taskcreatederror), Toast.LENGTH_SHORT, Gravity.BOTTOM, 0, 0);

                    /*
                    View toastView = getLayoutInflater().inflate(R.layout.activity_toast_custom_view2, null);

                    // Initiate the Toast instance.
                    Toast toast = new Toast(getContext());
                    // Set custom view in toast.
                    toast.setView(toastView);
                    toast.setDuration(Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.BOTTOM, 0, 0);
                    toast.show();
                    */
                    }
                }
                //MyApplication.getDatabase().tagDao().insert();

                //MyApplication.getDatabase().taskDao().insert(task);
                //MyApplication.getDatabase().
                //MyApplication.getDatabase().endTransaction();
                //FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                //fragmentTransaction.remove(this);
                //getActivity().onBackPressed();
                closeFragment();
                FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.popBackStack();
            }
        });

        Button imgbtncanceltask = (Button) rootView.findViewById(R.id.btncanceltask);
        imgbtncanceltask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeFragment();
                FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.popBackStack();
            }
        });



        return rootView;
    }

    private void closeFragment(){
        Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().remove(this).commit();
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void getProject(Node node) {
        ///projectTitle.setText(node.getName());
        projectId = ((Long)node.getId()).longValue();
        ltaskproject.removeAllViews();
        if (projectId > 0) {
            Project project = MyApplication.getDatabase().projectDao().getProjectById(projectId);
            //ltaskproject.removeAllViews();
            LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);
            ImageView iv = new ImageView(getActivity());
            iv.setImageResource(R.drawable.folder);
            iv.setLayoutParams(lParams);

            ltaskproject.addView(iv);

            lParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            RoundTextView rtv1 = new RoundTextView(getActivity());
            //rtv1.setText(lstTask.get(0).getTitle());

            rtv1.setCorner(20);
            rtv1.setPadding(10, 0, 10, 0);
            //rtv1.setCorner(5, 5, 5, 5);
            //rtv1.setBgColor(Color.parseColor(tags.get(j).getColor()));
            rtv1.setTextColor(R.color.black);


            try {
                rtv1.setBgColor(Color.parseColor(project.getColor()));
            } catch (Exception ex) {
                rtv1.setBgColor(Color.parseColor(DEFAULT_PROJECT_COLOR));
            }
            //rtv1.setCorner(2, 2, 2, 2);
            //rtv1.setCorner(5);

            rtv1.setText(project.getTitle());

            ltaskproject.addView(rtv1, lParams);
        }


        //Log.e("444444444", node.getName());
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void getTags(List<Tag> tags) {

        ltasktags.removeAllViews();

        if (tags != null) {
            lsttags = new ArrayList<Tag>();
            lsttags.addAll(tags);
            if (tags.size() > 0) {

                //LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);


                //iv.setMinimumWidth(25);
                //iv.setMinimumHeight(25);
                //iv.getLayoutParams().width = 25;
                //iv.getLayoutParams().height = 25;
                //iv.setMaxWidth(25);
                //iv.setMaxHeight(25);
                //iv.setla



                //ltasktags.addView(iv);



                for (int j = 0; j < tags.size(); j++) {

                    LinearLayout.LayoutParams lParams2 = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);

                    ImageView iv = new ImageView(getActivity());
                    iv.setImageResource(R.drawable.merchandising);
                    iv.setLayoutParams(lParams2);
                    try {
                        iv.setColorFilter(Color.parseColor(tags.get(j).getColor()));
                    } catch (Exception e){
                        iv.setColorFilter(Color.parseColor("#000000"));
                    }

                    ltasktags.addView(iv, lParams2);
                    RoundTextView rtv1 = new RoundTextView(getActivity());
                    //rtv1.setText(lstTask.get(0).getTitle());

                    rtv1.setCorner(20);
                    rtv1.setPadding(10, 0, 10, 0);
                    //rtv1.setCorner(5, 5, 5, 5);
                    rtv1.setBgColor(Utils.parseColor(tags.get(j).getColor()));
                    rtv1.setTextColor(R.color.black);

                    //rtv1.setBgColor(Color.parseColor(lstTag.get(i).getColor()));
                    //rtv1.setCorner(2, 2, 2, 2);
                    //rtv1.setCorner(5);
                    rtv1.setText(tags.get(j).getTitle());
                    LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    ltasktags.addView(rtv1, lParams);
                }
            }
        }
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void getTarget(Target target) {

        if (target != null) {
            targetId = target.getId();
            //Project project = MyApplication.getDatabase().projectDao().getProjectById(projectId);
            ltasktarget.removeAllViews();
            LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);
            ImageView iv = new ImageView(getActivity());
            iv.setImageResource(R.drawable.target4);
            iv.setLayoutParams(lParams);

            ltasktarget.addView(iv);

            lParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            RoundTextView rtv1 = new RoundTextView(getActivity());
            //rtv1.setText(lstTask.get(0).getTitle());

            rtv1.setCorner(20);
            rtv1.setPadding(10, 0, 10, 0);
            //rtv1.setCorner(5, 5, 5, 5);
            //rtv1.setBgColor(Color.parseColor(tags.get(j).getColor()));
            rtv1.setTextColor(R.color.black);


            try {
                rtv1.setBgColor(Color.parseColor(target.getColor()));
            } catch (Exception ex) {
                rtv1.setBgColor(Color.parseColor(DEFAULT_PROJECT_COLOR));
            }
            //rtv1.setCorner(2, 2, 2, 2);
            //rtv1.setCorner(5);

            rtv1.setText(target.getTitle());

            ltasktarget.addView(rtv1, lParams);
        }
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void getPriority(Priority priority) {

        priorityId = priority.getId();

        ltaskpriority.removeAllViews();

        LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);

        ImageView iv = new ImageView(getActivity());
        //iv.setImageResource(R.drawable.pririty);
        iv.setImageResource(R.drawable.priority2);

        //iv.setMinimumWidth(25);
        //iv.setMinimumHeight(25);
        //iv.getLayoutParams().width = 25;
        //iv.getLayoutParams().height = 25;
        //iv.setMaxWidth(25);
        //iv.setMaxHeight(25);
        //iv.setla



        int color = Color.parseColor(priority.getColor());
        //iv.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
        iv.setColorFilter(color);
        //iv.set

        iv.setLayoutParams(lParams);


        ltaskpriority.addView(iv);

        priorityTitle.setText(priority.getTitle());
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void getContexts(List<Contekst> conteksts) {
        //ltaskcontext
        ltaskcontext.removeAllViews();

        if (conteksts != null) {
            lstConteksts = new ArrayList<Contekst>();
            lstConteksts.addAll(conteksts);
            if (conteksts.size() > 0) {

                LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);

                ImageView iv = new ImageView(getActivity());
                iv.setImageResource(R.drawable.context);
                //iv.setMinimumWidth(25);
                //iv.setMinimumHeight(25);
                //iv.getLayoutParams().width = 25;
                //iv.getLayoutParams().height = 25;
                //iv.setMaxWidth(35);
                //iv.setMaxHeight(35);
                iv.setLayoutParams(lParams);
                //iv.setla

                iv.setLayoutParams(lParams);

                ltaskcontext.addView(iv);

                lParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

                for (int j = 0; j < conteksts.size(); j++) {


                    RoundTextView rtv1 = new RoundTextView(getActivity());
                    //rtv1.setText(lstTask.get(0).getTitle());

                    rtv1.setCorner(20);
                    rtv1.setPadding(10, 0, 10, 0);
                    //rtv1.setCorner(5, 5, 5, 5);
                    rtv1.setBgColor(Color.parseColor(conteksts.get(j).getColor()));
                    rtv1.setTextColor(R.color.black);

                    //rtv1.setBgColor(Color.parseColor(lstTag.get(i).getColor()));
                    //rtv1.setCorner(2, 2, 2, 2);
                    //rtv1.setCorner(5);
                    rtv1.setText(conteksts.get(j).getTitle());

                    ltaskcontext.addView(rtv1, lParams);
                }
            }
        }

        /*
        LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(Const.LAYOUT_DEFAULT_WIDTH, Const.LAYOUT_DEFAULT_HEIGHT);

        ImageView iv = new ImageView(getActivity());
        iv.setImageResource(R.drawable.up);
        //iv.setMinimumWidth(25);
        //iv.setMinimumHeight(25);
        //iv.getLayoutParams().width = 25;
        //iv.getLayoutParams().height = 25;
        //iv.setMaxWidth(25);
        //iv.setMaxHeight(25);
        //iv.setla



        int color = Color.parseColor(priority.getColor());
        iv.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
        //iv.set

        iv.setLayoutParams(lParams);


        ltaskpriority.addView(iv);

        priorityTitle.setText(priority.getTitle());
        */


    }

    @Override
    public void getDateEnd(String date, long datemls) {
        dateEnd = new Date(datemls);
        dateendTitle.setText(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy HH:mm"), dateEnd));

    }

    @Override
    public void getDateBegin(String date, long datemls) {
        dateBegin = new Date(datemls);
        dateBeginTitle.setText(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy HH:mm"), dateBegin));
    }

    @Override
    public void getTypeOfTask(TaskTypes tasktype) {
        taskTypes = tasktype;
    }
}
