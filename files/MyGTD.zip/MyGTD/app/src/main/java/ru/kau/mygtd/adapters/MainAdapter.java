package ru.kau.mygtd.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.apg.mobile.roundtextview.RoundTextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.common.interfaces.ClickListener;
import ru.kau.mygtd.objects.Category;
import ru.kau.mygtd.objects.InfoStatus;
import ru.kau.mygtd.objects.TaskStatus;
import ru.kau.mygtd.utils.Const;
import ru.kau.mygtd.utils.Utils;

import static ru.kau.mygtd.utils.Const.DEFAULT_COLLAPSE_ICON;
import static ru.kau.mygtd.utils.Const.DEFAULT_EXPANDED_ICON;

//import android.support.annotation.NonNull;
//import android.support.v7.widget.RecyclerView;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder>{

    private Context c;
    private List<Category> lstCategories;


    private ClickListener clicklistener = null;

    public MainAdapter(Context c, List<Category> lstCategories){
        this.c = c;
        this.lstCategories = lstCategories;
    }

    /*
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {




        return convertView;

    }
    */


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v= LayoutInflater.from(c).inflate(R.layout.main_cardview,viewGroup,false);

        /*GradientDrawable drawable = new GradientDrawable();
        drawable.setStroke(5, R.color.black);
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(20);
        v.setBackground(drawable);*/

        return new ViewHolder(v);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.title.setText(lstCategories.get(i).getTitle());
        //viewHolder.title.setWidth(75);

        //setAllUnvisible(viewHolder);
        switch (i){
            case 0:
                InfoStatus infoStatus = MyApplication.getDatabase().infoStatusDao().getById(1);
                long count = MyApplication.getDatabase().informationDao().getCountByStatus(infoStatus.getId());

                //setAllUnvisible(viewHolder);
                viewHolder.rtv2.setCorner(16, 0, 0, 16);

                viewHolder.rtv2.setBgColor(Color.parseColor(infoStatus.getColor()));
                viewHolder.iv1.setColorFilter(Color.parseColor(infoStatus.getColor()));
                //viewHolder.rtv1.setBgColor(Color.parseColor("#2196F3"));

                viewHolder.rtv2.setText(" " + Long.toString(count) + " ");

                viewHolder.rtv2.setVisibility(View.VISIBLE);

                //viewHolder.notifyAll();//notifyItemChanged();



                infoStatus = MyApplication.getDatabase().infoStatusDao().getById(2);
                count = MyApplication.getDatabase().informationDao().getCountByStatus(infoStatus.getId());



                viewHolder.rtv3.setCorner(0, 0, 0, 0);

                viewHolder.rtv3.setBgColor(Color.parseColor(infoStatus.getColor()));
                viewHolder.iv2.setColorFilter(Color.parseColor(infoStatus.getColor()));
                viewHolder.rtv3.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv3.setVisibility(View.VISIBLE);

                infoStatus = MyApplication.getDatabase().infoStatusDao().getById(3);
                count = MyApplication.getDatabase().informationDao().getCountByStatus(infoStatus.getId());


                viewHolder.rtv4.setCorner(0, 16, 16, 0);

                viewHolder.rtv4.setBgColor(Color.parseColor(infoStatus.getColor()));
                viewHolder.iv3.setColorFilter(Color.parseColor(infoStatus.getColor()));
                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);


                viewHolder.iv4.setVisibility(View.INVISIBLE);
                viewHolder.txtv4.setVisibility(View.INVISIBLE);

                viewHolder.txtv1.setText(R.string.newinfo);
                viewHolder.txtv2.setText(R.string.workinfo);
                viewHolder.txtv3.setText(R.string.archiveinfo);

                return;
            case 1:
                //infoStatus = MyApplication.getDatabase().infoStatusDao().getById(1);
                //count = MyApplication.getDatabase().informationDao().getCountByStatus(infoStatus.getId());


                TaskStatus taskStatus = MyApplication.getDatabase().taskStatusDao().getById(2);
                count = MyApplication.getDatabase().taskDao().getCountByStatus(taskStatus.getId());
                //setAllUnvisible(viewHolder);

                viewHolder.rtv1.setCorner(16, 0, 0, 16);

                viewHolder.rtv1.setBgColor(Color.parseColor(taskStatus.getColor()));
                viewHolder.iv1.setColorFilter(Color.parseColor(taskStatus.getColor()));

                viewHolder.rtv1.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv1.setVisibility(View.VISIBLE);


                taskStatus = MyApplication.getDatabase().taskStatusDao().getById(3);
                count = MyApplication.getDatabase().taskDao().getCountByStatus(taskStatus.getId());
                //setAllUnvisible(viewHolder);

                viewHolder.rtv2.setCorner(0, 0, 0, 0);

                viewHolder.rtv2.setBgColor(Color.parseColor(taskStatus.getColor()));
                viewHolder.iv2.setColorFilter(Color.parseColor(taskStatus.getColor()));

                viewHolder.rtv2.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv2.setVisibility(View.VISIBLE);

                taskStatus = MyApplication.getDatabase().taskStatusDao().getById(4);
                count = MyApplication.getDatabase().taskDao().getCountByStatus(taskStatus.getId());
                //setAllUnvisible(viewHolder);

                viewHolder.rtv3.setCorner(0, 0, 0, 0);

                viewHolder.rtv3.setBgColor(Color.parseColor(taskStatus.getColor()));
                viewHolder.iv3.setColorFilter(Color.parseColor(taskStatus.getColor()));

                viewHolder.rtv3.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv3.setVisibility(View.VISIBLE);

                taskStatus = MyApplication.getDatabase().taskStatusDao().getById(6);
                count = MyApplication.getDatabase().taskDao().getCountByStatus(taskStatus.getId());
                //setAllUnvisible(viewHolder);

                viewHolder.rtv4.setCorner(0, 16, 16, 0);

                viewHolder.rtv4.setBgColor(Color.parseColor(taskStatus.getColor()));
                viewHolder.iv4.setColorFilter(Color.parseColor(taskStatus.getColor()));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);

                viewHolder.txtv1.setText(R.string.newtask);
                viewHolder.txtv2.setText(R.string.worktask);
                viewHolder.txtv3.setText(R.string.pausetask);
                viewHolder.txtv4.setText(R.string.completetask);

                return;
            case 2:

                //taskStatus = MyApplication.getDatabase().taskStatusDao().getById(1);
                count = MyApplication.getDatabase().taskDao().getCountByDate(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));


                //infoStatus = MyApplication.getDatabase().infoStatusDao().getById(1);
                //count = MyApplication.getDatabase().informationDao().getCountByStatus(infoStatus.getId());



                viewHolder.rtv2.setCorner(16, 0, 0, 16);

                viewHolder.rtv2.setBgColor(Color.parseColor("#33FF99"));
                viewHolder.iv1.setColorFilter(Color.parseColor("#33FF99"));

                viewHolder.rtv2.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv2.setVisibility(View.VISIBLE);

                count = MyApplication.getDatabase().taskDao().getCountOutstanding(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));

                viewHolder.rtv3.setCorner(0, 0, 0, 0);

                viewHolder.rtv3.setBgColor(Color.parseColor("#FF0000"));
                viewHolder.iv2.setColorFilter(Color.parseColor("#FF0000"));

                viewHolder.rtv3.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv3.setVisibility(View.VISIBLE);

                count = MyApplication.getDatabase().taskDao().getCountAllActiveTasks();

                viewHolder.rtv4.setCorner(0, 16, 16, 0);

                viewHolder.rtv4.setBgColor(Color.parseColor(Const.DEFAULT_RTV_COLOR));
                viewHolder.iv3.setColorFilter(Color.parseColor(Const.DEFAULT_RTV_COLOR));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);

                viewHolder.txtv1.setText(R.string.todaytask);
                viewHolder.txtv2.setText(R.string.expiredtask);
                viewHolder.txtv3.setText(R.string.allactivetask);

                viewHolder.iv4.setVisibility(View.INVISIBLE);
                viewHolder.txtv4.setVisibility(View.INVISIBLE);

                return;

            case 3:



                count = MyApplication.getDatabase().taskDao().getCountAllTasksOfHotToday(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                //setAllUnvisible(viewHolder);

                viewHolder.rtv2.setCorner(16, 0, 0, 16);

                viewHolder.rtv2.setBgColor(Color.parseColor("#33FF99"));
                viewHolder.iv1.setColorFilter(Color.parseColor("#33FF99"));

                viewHolder.rtv2.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv2.setVisibility(View.VISIBLE);



                count = MyApplication.getDatabase().taskDao().getCountAllTasksOfHotOutstanding(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                //setAllUnvisible(viewHolder);

                viewHolder.rtv3.setCorner(0, 0, 0, 0);

                viewHolder.rtv3.setBgColor(Color.parseColor("#FF0000"));
                viewHolder.iv2.setColorFilter(Color.parseColor("#FF0000"));

                viewHolder.rtv3.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv3.setVisibility(View.VISIBLE);

                count = MyApplication.getDatabase().taskDao().getCountAllActiveTasksOfHot();
                //setAllUnvisible(viewHolder);

                viewHolder.rtv4.setCorner(0, 16, 16, 0);

                viewHolder.rtv4.setBgColor(Color.parseColor("#aa03A9F4"));
                viewHolder.iv3.setColorFilter(Color.parseColor("#aa03A9F4"));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);


                viewHolder.txtv1.setText(R.string.todaytask);
                viewHolder.txtv2.setText(R.string.expiredtask);
                viewHolder.txtv3.setText(R.string.allactivetask);

                viewHolder.iv4.setVisibility(View.INVISIBLE);
                viewHolder.txtv4.setVisibility(View.INVISIBLE);

                return;

            case 4:
                count = MyApplication.getDatabase().taskDao().getCountAllTasksOfFavouriteToday(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                //setAllUnvisible(viewHolder);

                viewHolder.rtv2.setCorner(16, 0, 0, 16);

                viewHolder.rtv2.setBgColor(Color.parseColor("#33FF99"));
                viewHolder.iv1.setColorFilter(Color.parseColor("#33FF99"));

                viewHolder.rtv2.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv2.setVisibility(View.VISIBLE);



                count = MyApplication.getDatabase().taskDao().getCountAllTasksOfFavouriteOutstanding(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                //setAllUnvisible(viewHolder);

                viewHolder.rtv3.setCorner(0, 0, 0, 0);

                viewHolder.rtv3.setBgColor(Color.parseColor("#FF0000"));
                viewHolder.iv2.setColorFilter(Color.parseColor("#FF0000"));

                viewHolder.rtv3.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv3.setVisibility(View.VISIBLE);

                count = MyApplication.getDatabase().taskDao().getCountAllActiveTasksOfFavourite();
                //setAllUnvisible(viewHolder);

                viewHolder.rtv4.setCorner(0, 16, 16, 0);

                viewHolder.rtv4.setBgColor(Color.parseColor("#aa03A9F4"));
                viewHolder.iv3.setColorFilter(Color.parseColor("#aa03A9F4"));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);


                viewHolder.txtv1.setText(R.string.todaytask);
                viewHolder.txtv2.setText(R.string.expiredtask);
                viewHolder.txtv3.setText(R.string.allactivetask);

                viewHolder.iv4.setVisibility(View.INVISIBLE);
                viewHolder.txtv4.setVisibility(View.INVISIBLE);

                viewHolder.iv2.setVisibility(View.INVISIBLE);
                viewHolder.iv3.setVisibility(View.INVISIBLE);
                viewHolder.iv4.setVisibility(View.INVISIBLE);

                return;

            case 5:

                count = MyApplication.getDatabase().taskDao().getCountAllClosedTasks();
                //setAllUnvisible(viewHolder);

                viewHolder.rtv4.setCorner(16, 16, 16, 16);

                viewHolder.rtv4.setBgColor(Color.parseColor("#aa03A9F4"));
                viewHolder.iv1.setColorFilter(Color.parseColor("#aa03A9F4"));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);count = MyApplication.getDatabase().taskDao().getCountAllClosedTasks();
                //setAllUnvisible(viewHolder);

                viewHolder.rtv4.setCorner(16, 16, 16, 16);

                viewHolder.rtv4.setBgColor(Color.parseColor("#aa03A9F4"));
                //viewHolder.iv3.setColorFilter(Color.parseColor("#aa03A9F4"));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);

                viewHolder.txtv2.setVisibility(View.INVISIBLE);
                viewHolder.txtv3.setVisibility(View.INVISIBLE);
                viewHolder.txtv4.setVisibility(View.INVISIBLE);
                viewHolder.txtv1.setText(R.string.completedtasks);
                viewHolder.iv2.setVisibility(View.INVISIBLE);
                viewHolder.iv3.setVisibility(View.INVISIBLE);
                viewHolder.iv4.setVisibility(View.INVISIBLE);

                return;

            case 6:

                taskStatus = MyApplication.getDatabase().taskStatusDao().getById(-1);
                count = MyApplication.getDatabase().taskDao().getCountByStatus(taskStatus.getId());
                //setAllUnvisible(viewHolder);

                viewHolder.rtv4.setCorner(16, 16, 16, 16);

                viewHolder.rtv4.setBgColor(Color.parseColor(taskStatus.getColor()));
                viewHolder.iv1.setColorFilter(Color.parseColor(taskStatus.getColor()));

                viewHolder.rtv4.setText(" " + Long.toString(count) + " ");
                viewHolder.rtv4.setVisibility(View.VISIBLE);




                viewHolder.txtv2.setVisibility(View.INVISIBLE);
                viewHolder.txtv3.setVisibility(View.INVISIBLE);
                viewHolder.txtv4.setVisibility(View.INVISIBLE);
                viewHolder.txtv1.setText(R.string.sometime);
                viewHolder.iv2.setVisibility(View.INVISIBLE);
                viewHolder.iv3.setVisibility(View.INVISIBLE);
                viewHolder.iv4.setVisibility(View.INVISIBLE);



                return;


        }

        //viewHolder.notifyAll();
        //this.notifyItemChanged(0);
        //this.

    }

    @Override
    public int getItemCount() {
        return lstCategories.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView title;
        private LinearLayout main;
        LinearLayout linLayout;
        RoundTextView rtv1;
        RoundTextView rtv2;
        RoundTextView rtv3;
        RoundTextView rtv4;

        ImageView iv1;
        ImageView iv2;
        ImageView iv3;
        ImageView iv4;

        TextView txtv1;
        TextView txtv2;
        TextView txtv3;
        TextView txtv4;

        View layout2;
        //TextView textView;

        ImageView expandedIcon;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.title);
            main = (LinearLayout) itemView.findViewById(R.id.main);
            linLayout = (LinearLayout) itemView.findViewById(R.id.lnrLayout);

            layout2 = itemView.findViewById(R.id.legend);
            layout2.setVisibility(View.GONE);
            //rtv1 = new RoundTextView(c);
            //rtv1 = new RoundTextView(c);
            rtv1 = (RoundTextView) itemView.findViewById(R.id.rtv1);
            rtv2 = (RoundTextView) itemView.findViewById(R.id.rtv2);
            rtv3 = (RoundTextView) itemView.findViewById(R.id.rtv3);
            rtv4 = (RoundTextView) itemView.findViewById(R.id.rtv4);
            //textView = new TextView(c);

            iv1 = (ImageView) itemView.findViewById(R.id.square1);
            txtv1 = (TextView) itemView.findViewById(R.id.txt1);
            iv2 = (ImageView) itemView.findViewById(R.id.square2);
            txtv2 = (TextView) itemView.findViewById(R.id.txt2);
            iv3 = (ImageView) itemView.findViewById(R.id.square3);
            txtv3 = (TextView) itemView.findViewById(R.id.txt3);
            iv4 = (ImageView) itemView.findViewById(R.id.square4);
            txtv4 = (TextView) itemView.findViewById(R.id.txt4);

            rtv1.setVisibility(View.INVISIBLE);
            rtv2.setVisibility(View.INVISIBLE);
            rtv3.setVisibility(View.INVISIBLE);
            rtv4.setVisibility(View.INVISIBLE);

            expandedIcon = (ImageView) itemView.findViewById(R.id.expandedIcon);
            expandedIcon.setImageResource(DEFAULT_COLLAPSE_ICON);
            //expandedIcon.setMinimumWidth(35);

            expandedIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (layout2.getVisibility() != View.GONE) {
                        layout2.setVisibility(View.GONE);
                    } else {
                        layout2.setVisibility(View.VISIBLE);
                    }

                    if (layout2.getVisibility() != View.GONE) {
                        //TransitionManager.beginDelayedTransition(layout2);
                        expandedIcon.setImageResource(DEFAULT_EXPANDED_ICON);
                        //layout2.setVisibility(View.GONE);
                        return;
                        //layout.refreshDrawableState();
                        //layout2.refreshDrawableState();
                        //layout2.sethe
                    } else {
                        //TransitionManager.beginDelayedTransition(layout2);
                        expandedIcon.setImageResource(DEFAULT_COLLAPSE_ICON);
                        //layout2.setVisibility(View.VISIBLE);
                        return;
                        //layout.refreshDrawableState();
                        //layout2.refreshDrawableState();
                    }
                    //divider.setVisibility(description.getVisibility());
                }
            });

            main.setOnClickListener(new View.OnClickListener(){
                                        @Override
                                        public void onClick(View v) {
                                            //Toast.makeText(itemView.getContext(), "Position:" + Integer.toString(getPosition()), Toast.LENGTH_SHORT).show();
                                            if(clicklistener !=null){
                                                clicklistener.itemClicked(v,getAdapterPosition(), 1);
                                            }
                                        }
                                    }
            );
        }


    }

    public void setClickListener(ClickListener clickListener){
        this.clicklistener = clickListener;
    }

    public void setAllUnvisible(@NonNull ViewHolder viewHolder){
        viewHolder.rtv1.setVisibility(View.INVISIBLE);
        viewHolder.rtv2.setVisibility(View.INVISIBLE);
        viewHolder.rtv3.setVisibility(View.INVISIBLE);
        viewHolder.rtv4.setVisibility(View.INVISIBLE);
    }

}
