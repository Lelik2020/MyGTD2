package ru.kau.mygtd.db;

import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.common.enums.PrStatus;
import ru.kau.mygtd.objects.Category;
import ru.kau.mygtd.objects.Contekst;
import ru.kau.mygtd.objects.InfoStatus;
import ru.kau.mygtd.objects.Priority;
import ru.kau.mygtd.objects.Project;
import ru.kau.mygtd.objects.ProjectStatus;
import ru.kau.mygtd.objects.Tag;
import ru.kau.mygtd.objects.Target;
import ru.kau.mygtd.objects.TaskStatus;
import ru.kau.mygtd.objects.TaskTypes;

public class DbCreator {

    public static void firstInit(){


        firstInitSpr();

        firstInitData();




    }

    public static void firstInitSpr(){

        // Справочник типов задач

        TaskTypes taskType = new TaskTypes();
        taskType.setId(1);
        taskType.setTitle("Эпик");
        taskType.setVusualTitle("EPIC");
        taskType.setColor("#6A5ACD");

        MyApplication.getDatabase().taskTypesDao().insert(taskType);

        taskType = new TaskTypes();
        taskType.setId(2);
        taskType.setTitle("История");
        taskType.setVusualTitle("STORY");
        taskType.setColor("#00FF00");

        MyApplication.getDatabase().taskTypesDao().insert(taskType);

        taskType = new TaskTypes();
        taskType.setId(3);
        taskType.setTitle("Задача");
        taskType.setVusualTitle("TASK");
        taskType.setColor("#0000FF");

        MyApplication.getDatabase().taskTypesDao().insert(taskType);

        taskType = new TaskTypes();
        taskType.setId(4);
        taskType.setTitle("Дефект");
        taskType.setVusualTitle("BUG");
        taskType.setColor("#FF0000");

        MyApplication.getDatabase().taskTypesDao().insert(taskType);

        taskType = new TaskTypes();
        taskType.setId(5);
        taskType.setTitle("Вопрос");
        taskType.setVusualTitle("QUESTION");
        taskType.setColor("#808080");

        MyApplication.getDatabase().taskTypesDao().insert(taskType);

        // ----------------------------------------------------------


        Category category = new Category();
        category.setId(1L);
        category.setTitle("Входящие");
        category.setDescription("9999");
        category.setGrp(1);
        //category.setUsed();
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(2L);
        category.setTitle("Все задачи");
        category.setDescription("8888");
        category.setGrp(1);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(3L);
        category.setTitle("Сегодня");
        category.setDescription("8888");
        category.setGrp(1);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(4L);
        category.setTitle("Горящие");
        category.setDescription("8888");
        category.setGrp(1);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(5L);
        category.setTitle("Избранные");
        category.setDescription("8888");
        category.setGrp(1);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(6L);
        category.setTitle("Завершенные");
        category.setDescription("8888");
        category.setGrp(1);
        MyApplication.getDatabase().categoryDao().insert(category);

        // --------------------------------------------------
        category = new Category();
        category.setId(7L);
        category.setTitle("Проекты");
        category.setDescription("7777");
        category.setGrp(2);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(8L);
        category.setTitle("Цели");
        category.setDescription("7777");
        category.setGrp(2);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(9L);
        category.setTitle("Тэги");
        category.setDescription("7777");
        category.setGrp(2);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(10L);
        category.setTitle("Контексты");
        category.setDescription("7777");
        category.setGrp(2);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(11L);
        category.setTitle("Календарь");
        category.setDescription("5555");
        category.setGrp(2);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(12L);
        category.setTitle("Следующие действия");
        category.setDescription("4444");
        category.setGrp(2);
        MyApplication.getDatabase().categoryDao().insert(category);

        category = new Category();
        category.setId(13L);
        category.setTitle("Когда-нибудь");
        category.setDescription("4444");
        category.setGrp(1);
        MyApplication.getDatabase().categoryDao().insert(category);

        InfoStatus infoStatus = new InfoStatus();
        infoStatus.setId(1L);
        infoStatus.setTitle("Новая");
        infoStatus.setDescription("");
        infoStatus.setColor("#FF0000");
        MyApplication.getDatabase().infoStatusDao().insert(infoStatus);
        infoStatus = new InfoStatus();
        infoStatus.setId(2L);
        infoStatus.setTitle("Обработана");
        infoStatus.setDescription("");
        infoStatus.setColor("#67E667");
        MyApplication.getDatabase().infoStatusDao().insert(infoStatus);
        infoStatus = new InfoStatus();
        infoStatus.setId(3L);
        infoStatus.setTitle("В архиве");
        infoStatus.setDescription("");
        infoStatus.setColor("#808080");
        MyApplication.getDatabase().infoStatusDao().insert(infoStatus);


        TaskStatus taskStatus = new TaskStatus();
        taskStatus.setId(1L);
        taskStatus.setTitle("Статус не определен");
        taskStatus.setColor("#FFA500");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);

        taskStatus = new TaskStatus();
        taskStatus.setId(2L);
        taskStatus.setTitle("Новая");
        taskStatus.setColor("#67E667");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);
        taskStatus = new TaskStatus();
        taskStatus.setId(3L);
        taskStatus.setTitle("В работе");
        taskStatus.setColor("#2196F3");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);
        taskStatus = new TaskStatus();
        taskStatus.setId(4L);
        taskStatus.setTitle("Пауза");
        taskStatus.setColor("#009688");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);
        taskStatus = new TaskStatus();
        taskStatus.setId(5L);
        taskStatus.setTitle("Отложено");
        taskStatus.setColor("#808080");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);
        taskStatus = new TaskStatus();
        taskStatus.setId(6L);
        taskStatus.setTitle("Выполнено");
        taskStatus.setColor("#009688");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);

        taskStatus = new TaskStatus();
        taskStatus.setId(-1L);
        taskStatus.setTitle("Когда-нибудь");
        taskStatus.setColor("#FF4081");
        MyApplication.getDatabase().taskStatusDao().insert(taskStatus);

        // ---------------------------------------------------------------------

        ProjectStatus projectStatus = new ProjectStatus();
        projectStatus.setId(1L);
        projectStatus.setTitle("Активный");

        projectStatus = new ProjectStatus();
        projectStatus.setId(2L);
        projectStatus.setTitle("Отменен");

        projectStatus = new ProjectStatus();
        projectStatus.setId(3L);
        projectStatus.setTitle("Архивный");

        Priority priority = new Priority();
        priority.setId(1L);
        priority.setTitle("Наивысший");
        priority.setColor("#FF0000");
        MyApplication.getDatabase().priorityDao().insert(priority);

        priority = new Priority();
        priority.setId(2L);
        priority.setTitle("Высокий");
        priority.setColor("#FF6600");
        MyApplication.getDatabase().priorityDao().insert(priority);

        priority = new Priority();
        priority.setId(3L);
        priority.setTitle("Средний");
        priority.setColor("#00FF00");
        MyApplication.getDatabase().priorityDao().insert(priority);

        priority = new Priority();
        priority.setId(4L);
        priority.setTitle("Низкий");
        priority.setColor("#3333FF");
        MyApplication.getDatabase().priorityDao().insert(priority);

        priority = new Priority();
        priority.setId(5L);
        priority.setTitle("Без приоритета");
        priority.setColor("#999999");
        MyApplication.getDatabase().priorityDao().insert(priority);

    }

    public static void firstInitData(){
        Target target = new Target();
        target.setId(1L);
        target.setTitle("Выход на ТЕСТ");
        target.setDescription("1111");
        MyApplication.getDatabase().targetDao().insert(target);

        target = new Target();
        target.setId(2L);
        target.setTitle("Выход на ПРОМ");
        target.setDescription("222222");
        MyApplication.getDatabase().targetDao().insert(target);

        target = new Target();
        target.setId(3L);
        target.setTitle("Изучение английского языка");
        target.setDescription("3333333");
        MyApplication.getDatabase().targetDao().insert(target);

        /*
        category = new Category();
        category.setId(7L);
        category.setTitle("Лист ожидания");
        category.setDescription("3333");
        MyApplication.getDatabase().categoryDao().insert(category);

         */



        // ---------------------------------------------------------------------





        Project project = new Project();
        project.setId(1L);
        project.setTitle("Работа");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Здесь будут находиться все рабочие проекты");
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);

        project = new Project();
        project.setId(2L);
        project.setTitle("Личное");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Здесь будут находиться все личные проекты");
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);

        project = new Project();
        project.setId(3L);
        project.setTitle("Логистика банковских продуктов");
        project.setSearchtitle(project.getTitle());
        project.setDescription("333333");
        project.setParentid(1L);
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);

        project = new Project();
        project.setId(4L);
        project.setTitle("Персонализация сайта");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Проект \"Персонализация сайта \"");
        project.setParentid(1L);
        project.setPrStatus(PrStatus.ACTIVE);

        MyApplication.getDatabase().projectDao().insert(project);

        project = new Project();
        project.setId(5L);
        project.setTitle("Performance Managment");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Проект Performance Managment");
        project.setParentid(1L);
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);




        project = new Project();
        project.setId(6L);
        project.setTitle("MyReader");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Проект MyReader. ");
        project.setParentid(2L);
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);

        project = new Project();
        project.setId(7L);
        project.setTitle("MyGTD");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Проект MyGTD. ");
        project.setParentid(2L);
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);

        project = new Project();
        project.setId(8L);
        project.setTitle("Маркетинговый оптимизатор");
        project.setSearchtitle(project.getTitle());
        project.setDescription("Проект Performance Managment");
        project.setParentid(1L);
        project.setPrStatus(PrStatus.ACTIVE);
        MyApplication.getDatabase().projectDao().insert(project);

        /*Task task = new Task();
        task.setId(1L);
        task.setTitle("ОТАР. Разработка и согласование");
        task.setSearchtitle(task.getTitle().toUpperCase());
        task.setDescription("Разработать и согласовать ОТАР");
        task.setPriority_id(1L);
        task.setStatus(Status.INPROGRESS);
        task.setDateCreate(new Date());
        task.setDateBeginStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), task.getDateCreate()));
        task.setTarget_id(2L);
        task.setProject_id(3L);
        MyApplication.getDatabase().taskDao().insert(task);

        task = new Task();
        task.setId(2L);
        task.setTitle("Второе задание");
        task.setSearchtitle(task.getTitle().toUpperCase());
        task.setDescription("Описание второго задания");
        task.setPriority_id(4L);
        task.setStatus(Status.COMPLETED);
        task.setProject_id(2L);
        task.setTarget_id(2L);
        task.getDateEnd();
        task.setTypeOfTask(TypeOfTask.BUG);
        MyApplication.getDatabase().taskDao().insert(task);



        task = new Task();
        task.setId(3L);
        task.setParenttask_id(2L);
        task.setTitle("Третье задание");
        task.setSearchtitle(task.getTitle().toUpperCase());
        task.setDescription("Описание третьего задания");
        task.setPriority_id(1L);
        task.setStatus(Status.INPROGRESS);
        task.setDateEnd(new GregorianCalendar(2020, 0 , 21).getTime());
        task.setDateEndStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), task.getDateEnd()));
        MyApplication.getDatabase().taskDao().insert(task);

        task = new Task();
        task.setId(4L);
        task.setTitle("Четвертое задание");
        task.setSearchtitle(task.getTitle().toUpperCase());
        task.setDescription("Описание четвертого задания");
        task.setPriority_id(3L);
        task.setStatus(Status.INPROGRESS);
        task.setDateEnd(new GregorianCalendar(2020, 0 , 22).getTime());
        task.setDateEndStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), task.getDateEnd()));
        task.setTypeOfTask(TypeOfTask.BUG);

        task.setTarget_id(1L);
        MyApplication.getDatabase().taskDao().insert(task);

        task = new Task();
        task.setId(5L);
        task.setTitle("Пятое задание");
        task.setSearchtitle(task.getTitle().toUpperCase());
        task.setDescription("Описание пятого задания");
        task.setPriority_id(1L);
        task.setStatus(Status.NEW);
        task.setProject_id(4L);
        task.setDateEndStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
        task.setTypeOfTask(TypeOfTask.BUG);
        MyApplication.getDatabase().taskDao().insert(task);

        task = new Task();
        task.setId(6L);
        task.setTitle("Задание когда-нибудь");
        task.setSearchtitle(task.getTitle().toUpperCase());
        task.setDescription("9999999");
        //task.setPriority_id(1L);
        task.setStatus(Status.SOMETIME);
        //task.setProject_id(4L);
        //task.setDateEndStr(Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
        MyApplication.getDatabase().taskDao().insert(task);




        Information information = new Information();
        information.setId(1L);
        information.setTitle("Информация 1");
        information.setSearchtitle(information.getTitle().toUpperCase());
        Date date = new Date(System.currentTimeMillis());
        //date = System.currentTimeMillis();
        information.setDateCreate(date);
        information.setDescription("1111");
        //information.setInfoStatus(infoStatus);
        information.setIdstatus(3);
        //information.setDateCreateString(Utils.dateToString(null, date));
        MyApplication.getDatabase().informationDao().insert(information);

        information = new Information();
        information.setId(2L);
        information.setTitle("Информация 2");
        information.setSearchtitle(information.getTitle().toUpperCase());
        date = new Date(System.currentTimeMillis());
        //date = System.currentTimeMillis();
        information.setDateCreate(date);
        information.setDescription("2222");
        information.setIdstatus(1);
        //information.setDateCreateString(Utils.dateToString(null, date));
        MyApplication.getDatabase().informationDao().insert(information);

        information = new Information();
        information.setId(3L);
        information.setTitle("Информация 3");
        information.setSearchtitle(information.getTitle().toUpperCase());
        date = new Date(System.currentTimeMillis());
        //date = System.currentTimeMillis();
        information.setDateCreate(date);
        information.setDescription("3333");
        information.setIdstatus(3);
        //information.setDateCreateString(Utils.dateToString(null, date));
        MyApplication.getDatabase().informationDao().insert(information);*/



        Tag tag = new Tag();
        tag.setId(1L);
        tag.setTitle("ОТАР");
        tag.setDescription("11111");
        tag.setColor("#FF0000");
        MyApplication.getDatabase().tagDao().insert(tag);

        tag = new Tag();
        tag.setId(2L);
        tag.setTitle("Согласование");
        tag.setDescription("11111");
        tag.setColor("#aa03A9F4");
        MyApplication.getDatabase().tagDao().insert(tag);

        /*TaskTagJoin taskTagJoin = new TaskTagJoin(2L, 1L);
        MyApplication.getDatabase().taskTagJoinDao().insert(taskTagJoin);
        taskTagJoin = new TaskTagJoin(2L, 2L);
        MyApplication.getDatabase().taskTagJoinDao().insert(taskTagJoin);
        taskTagJoin = new TaskTagJoin(3L, 1L);
        MyApplication.getDatabase().taskTagJoinDao().insert(taskTagJoin);
        taskTagJoin = new TaskTagJoin(4L, 2L);
        MyApplication.getDatabase().taskTagJoinDao().insert(taskTagJoin);*/

        Contekst contekst = new Contekst();
        contekst.setId(1L);
        contekst.setTitle("Дом");
        contekst.setColor("#2196F3");
        MyApplication.getDatabase().contextDao().insert(contekst);

        contekst = new Contekst();
        contekst.setId(2L);
        contekst.setTitle("Работа");
        contekst.setColor("#33FF99");
        MyApplication.getDatabase().contextDao().insert(contekst);

        contekst = new Contekst();
        contekst.setId(3L);
        contekst.setTitle("В метро");
        contekst.setColor("#C71585");
        MyApplication.getDatabase().contextDao().insert(contekst);

        /*TaskContextJoin taskContextJoin = new TaskContextJoin(2L, 1L);
        MyApplication.getDatabase().taskContextJoinDao().insert(taskContextJoin);

        taskContextJoin = new TaskContextJoin(5L, 1L);
        MyApplication.getDatabase().taskContextJoinDao().insert(taskContextJoin);
        taskContextJoin = new TaskContextJoin(5L, 3L);
        MyApplication.getDatabase().taskContextJoinDao().insert(taskContextJoin);*/
    }

}
