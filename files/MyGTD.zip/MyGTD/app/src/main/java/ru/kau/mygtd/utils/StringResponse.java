package ru.kau.mygtd.utils;

public interface StringResponse {
    public boolean onResultRecive(String string);
}
