package ru.kau.mygtd.interfaces;

import ru.kau.mygtd.objects.Target;

public interface DialogTargetChoice {

    public void getTarget(Target target);

}
