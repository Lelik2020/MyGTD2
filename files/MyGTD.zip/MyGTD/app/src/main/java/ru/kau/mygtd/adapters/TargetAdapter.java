package ru.kau.mygtd.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.apg.mobile.roundtextview.RoundTextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.objects.Target;
import ru.kau.mygtd.utils.Utils;

public class TargetAdapter extends RecyclerView.Adapter<TargetAdapter.ViewHolder>{

    private Context c;
    private List<Target> lstTargets;

    public TargetAdapter(Context c, List<Target> lstTargets) {
        this.c = c;
        this.lstTargets = lstTargets;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(c).inflate(R.layout.target_cardview, parent,false);

        return new TargetAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Target target = getItem(position);
        holder.title.setText(target.getTitle());

        long count = 0L;
        long count2 = 0L;
        long count3 = 0L;
        long count4 = 0L;

        count = MyApplication.getDatabase().taskDao().getCountAllTasksByTarget(target.getId());
        count2 = MyApplication.getDatabase().taskDao().getCountAllActiveTasksByTag(target.getId());
        count3 = MyApplication.getDatabase().taskDao().getCountByDateByTarget(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()), target.getId());
        count4 = MyApplication.getDatabase().taskDao().getCountOutstandingByTarget(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()), target.getId());

        holder.roundTextView.setCorner(16, 0, 0, 16);

        holder.roundTextView.setBgColor(Color.parseColor("#FF0000"));
        holder.roundTextView.setText(" " + Long.toString(count4) + " ");
        holder.roundTextView.setVisibility(View.VISIBLE);

        holder.roundTextView2.setCorner(0, 0, 0, 0);

        holder.roundTextView2.setBgColor(Color.parseColor("#33FF99"));
        holder.roundTextView2.setText(" " + Long.toString(count3) + " ");
        holder.roundTextView2.setVisibility(View.VISIBLE);

        holder.roundTextView3.setCorner(0, 0, 0, 0);

        holder.roundTextView3.setBgColor(Color.parseColor("#aa03A9F4"));
        holder.roundTextView3.setText(" " + Long.toString(count2) + " ");
        holder.roundTextView3.setVisibility(View.VISIBLE);

        holder.roundTextView4.setCorner(0, 16, 16, 0);

        holder.roundTextView4.setBgColor(Color.parseColor("#808080"));
        holder.roundTextView4.setText(" " + Long.toString(count) + " ");
        holder.roundTextView4.setVisibility(View.VISIBLE);

    }

    @Override
    public int getItemCount() {
        return lstTargets.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView title;
        RoundTextView roundTextView;
        RoundTextView roundTextView2;
        RoundTextView roundTextView3;
        RoundTextView roundTextView4;
        ImageView tagImage;




        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tagImage = (ImageView) itemView.findViewById(R.id.target_icon);
            title = (TextView) itemView.findViewById(R.id.targettitle);
            roundTextView = (RoundTextView) itemView.findViewById(R.id.targetcount1);
            roundTextView2 = (RoundTextView) itemView.findViewById(R.id.targetcount2);
            roundTextView3 = (RoundTextView) itemView.findViewById(R.id.targetcount3);
            roundTextView4 = (RoundTextView) itemView.findViewById(R.id.targetcount4);

        }
    }

    public Target getItem(int pos) {
        if (lstTargets == null || lstTargets.isEmpty()) {
            return null;
        }
        if (lstTargets.size() - 1 >= pos) {
            return lstTargets.get(pos);
        } else {
            return lstTargets.get(0);
        }
    }

}
