package ru.kau.mygtd.fragments;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.util.Date;
import java.util.Objects;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.objects.Information;
import ru.kau.mygtd.utils.Utils;
import ru.kau.mygtd.utils.ViewUtils;

import static ru.kau.mygtd.utils.Utils.DEFAULT_DATEFORMAT_WITHSECONDS;

//import android.support.v4.app.Fragment;

public class AddInformationFragment extends Fragment {

    private Information infoUpdate = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.addinfo_fragment, null);

        Bundle arguments = getArguments();


        TextView inputInfoShort = (TextView)rootView.findViewById(R.id.inputInfoShort);
        TextView inputInfoFull = (TextView)rootView.findViewById(R.id.inputInfoFull);


        if (arguments != null && arguments.containsKey("information")) {
            infoUpdate = (Information) arguments.getSerializable("information");
            inputInfoShort.setText(infoUpdate.getTitle());
            inputInfoFull.setText(infoUpdate.getDescription());
        }


        Button imgbtnsaveinfo = (Button) rootView.findViewById(R.id.btnsaveinfo);
        imgbtnsaveinfo.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if (arguments != null && arguments.containsKey("information")) {
                    infoUpdate.setTitle(inputInfoShort.getText().toString());
                    infoUpdate.setSearchtitle(infoUpdate.getTitle().toUpperCase());
                    infoUpdate.setDescription(inputInfoFull.getText().toString());
                    try{
                        MyApplication.getDatabase().informationDao().update(infoUpdate);
                        ViewUtils.viewPositiveToast(getContext(), getLayoutInflater(), String.valueOf(R.string.infoupdated), Toast.LENGTH_SHORT, Gravity.BOTTOM, 0, 0);
                    } catch (Exception e) {

                        ViewUtils.viewNegativeToast(getContext(), getLayoutInflater(), String.valueOf(R.string.infoupdatederror), Toast.LENGTH_SHORT, Gravity.BOTTOM, 0, 0);

                    }

                } else {
                    Information information = new Information();
                    information.setTitle(inputInfoShort.getText().toString());
                    information.setSearchtitle(information.getTitle().toUpperCase());
                    information.setDescription(inputInfoFull.getText().toString());
                    information.setDateCreate(new Date());
                    information.setDateCreateStr(Utils.dateToString(DEFAULT_DATEFORMAT_WITHSECONDS, information.getDateCreate()));
                    information.setIdstatus(1);
                    try {
                        MyApplication.getDatabase().informationDao().insert(information);
                        ViewUtils.viewPositiveToast(getContext(), getLayoutInflater(), (String) getResources().getText(R.string.infocreated), Toast.LENGTH_SHORT, Gravity.BOTTOM, 0, 0);
                    } catch (Exception e) {

                        ViewUtils.viewNegativeToast(getContext(), getLayoutInflater(), (String) getResources().getText(R.string.infocreatederror), Toast.LENGTH_SHORT, Gravity.BOTTOM, 0, 0);

                    }
                }

                closeFragment();
                FragmentManager fm = Objects.requireNonNull(getActivity()).getSupportFragmentManager();
                fm.popBackStack();

            }
        });

        Button imgbtncancelinfo = (Button) rootView.findViewById(R.id.btncancelinfo);
        imgbtncancelinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeFragment();
                FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.popBackStack();
            }
        });

        return rootView;
    }

    private void closeFragment(){
        Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().remove(this).commit();
    }

}
