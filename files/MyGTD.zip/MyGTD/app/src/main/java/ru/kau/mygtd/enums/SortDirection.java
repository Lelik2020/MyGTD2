package ru.kau.mygtd.enums;

public enum SortDirection {

    UP_TO_DOWN, // По убыванию
    DOWN_TO_UP  // По возрастанию

}
