package ru.kau.mygtd.interfaces;

public interface DialogDateEndChoice {

    public void getDateEnd(String date, long datemls);

}
