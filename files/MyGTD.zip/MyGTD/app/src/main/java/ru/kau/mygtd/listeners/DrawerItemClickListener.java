package ru.kau.mygtd.listeners;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class DrawerItemClickListener implements ListView.OnItemClickListener{

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {




        /*
        Fragment fragment = DrawerContentFragment.newInstance(mCouponMenu[position]);

        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.main_frame, fragment)
                .commit();

        mDrawerList.setItemChecked(position, true);
        setTitle(mCouponMenu[position]);
        mDrawerLayout.closeDrawer(mDrawerList);
        */
    }
}
