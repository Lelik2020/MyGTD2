package ru.kau.mygtd.interfaces;


import com.multilevel.treelist.Node;

public interface DialogProjectChoice {

    public void getProject(Node node);

}
