package ru.kau.mygtd.interfaces;

import java.util.List;

import ru.kau.mygtd.objects.Tag;

public interface DialogTagsChoice {

    public void getTags(List<Tag> tags);

}
