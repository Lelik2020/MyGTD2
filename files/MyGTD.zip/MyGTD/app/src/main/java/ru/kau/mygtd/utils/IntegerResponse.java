package ru.kau.mygtd.utils;

public interface IntegerResponse {

    public boolean onResultRecive(int result);

}
