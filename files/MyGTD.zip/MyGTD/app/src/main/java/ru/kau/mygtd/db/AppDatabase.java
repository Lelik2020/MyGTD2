package ru.kau.mygtd.db;

//import android.arch.persistence.room.Database;

//import android.arch.persistence.room.RoomDatabase;

//import android.arch.persistence.room.TypeConverters;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import ru.kau.mygtd.db.dao.CategoryDao;
import ru.kau.mygtd.db.dao.CommentDao;
import ru.kau.mygtd.db.dao.ContextDao;
import ru.kau.mygtd.db.dao.InfoStatusDao;
import ru.kau.mygtd.db.dao.InformationDao;
import ru.kau.mygtd.db.dao.MeetingDao;
import ru.kau.mygtd.db.dao.PriorityDao;
import ru.kau.mygtd.db.dao.ProjectDao;
import ru.kau.mygtd.db.dao.ProjectStatusDao;
import ru.kau.mygtd.db.dao.TagDao;
import ru.kau.mygtd.db.dao.TargetDao;
import ru.kau.mygtd.db.dao.TaskContextJoinDao;
import ru.kau.mygtd.db.dao.TaskDao;
import ru.kau.mygtd.db.dao.TaskStatusDao;
import ru.kau.mygtd.db.dao.TaskTagJoinDao;
import ru.kau.mygtd.db.dao.TaskTypesDao;
import ru.kau.mygtd.objects.Category;
import ru.kau.mygtd.objects.Comment;
import ru.kau.mygtd.objects.Contekst;
import ru.kau.mygtd.objects.InfoProjectJoin;
import ru.kau.mygtd.objects.InfoStatus;
import ru.kau.mygtd.objects.Information;
import ru.kau.mygtd.objects.Meeting;
import ru.kau.mygtd.objects.Priority;
import ru.kau.mygtd.objects.Project;
import ru.kau.mygtd.objects.ProjectStatus;
import ru.kau.mygtd.objects.Tag;
import ru.kau.mygtd.objects.Target;
import ru.kau.mygtd.objects.Task;
import ru.kau.mygtd.objects.TaskContextJoin;
import ru.kau.mygtd.objects.TaskStatus;
import ru.kau.mygtd.objects.TaskTagJoin;
import ru.kau.mygtd.objects.TaskTypes;
import ru.kau.mygtd.utils.Converters;

@Database(entities = {Task.class, Information.class, Project.class, Category.class, TaskStatus.class, Contekst.class,
                      Tag.class, InfoStatus.class,
                      TaskContextJoin.class, InfoProjectJoin.class, TaskTagJoin.class,
                      Priority.class, Meeting.class, Comment.class, ProjectStatus.class, Target.class,
                      TaskTypes.class},
                      version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class AppDatabase extends RoomDatabase {

    public abstract TaskDao taskDao();
    public abstract ProjectDao projectDao();
    public abstract CategoryDao categoryDao();
    public abstract TaskStatusDao taskStatusDao();
    public abstract ContextDao contextDao();
    public abstract InformationDao informationDao();
    public abstract InfoStatusDao infoStatusDao();
    public abstract MeetingDao meetingDao();
    public abstract ProjectStatusDao projectStatusDao();
    public abstract TagDao tagDao();
    public abstract TaskTagJoinDao taskTagJoinDao();
    public abstract TaskContextJoinDao taskContextJoinDao();

    public abstract TargetDao targetDao();

    public abstract PriorityDao priorityDao();

    public abstract CommentDao commentDao();

    public abstract TaskTypesDao taskTypesDao();

}

