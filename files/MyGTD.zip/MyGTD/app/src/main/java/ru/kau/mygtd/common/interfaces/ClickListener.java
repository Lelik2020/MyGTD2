package ru.kau.mygtd.common.interfaces;

import android.view.View;

public interface ClickListener {
    public void itemClicked(View view , int position, int grp);
}
