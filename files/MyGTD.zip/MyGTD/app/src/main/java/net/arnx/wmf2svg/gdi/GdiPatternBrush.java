package net.arnx.wmf2svg.gdi;

public interface GdiPatternBrush extends GdiObject {
	public byte[] getPattern();
}
