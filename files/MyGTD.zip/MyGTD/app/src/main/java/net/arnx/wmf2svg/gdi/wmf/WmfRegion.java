package net.arnx.wmf2svg.gdi.wmf;

import net.arnx.wmf2svg.gdi.GdiRegion;

class WmfRegion extends WmfObject implements GdiRegion {
	public WmfRegion(int id) {
		super(id);
	}
}
