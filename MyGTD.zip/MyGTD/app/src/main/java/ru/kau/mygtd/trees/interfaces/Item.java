package ru.kau.mygtd.trees.interfaces;

import java.util.List;

import ru.kau.mygtd.objects.Project;

public interface Item {
    public String getTitle();
    public int getIconResource();
    public List<Project> getChilds();
}
