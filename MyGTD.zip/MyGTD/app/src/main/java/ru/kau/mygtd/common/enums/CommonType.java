package ru.kau.mygtd.common.enums;

public enum CommonType {

    PROJECT,
    TAG,
    TARGET,
    CONTEXT

}
