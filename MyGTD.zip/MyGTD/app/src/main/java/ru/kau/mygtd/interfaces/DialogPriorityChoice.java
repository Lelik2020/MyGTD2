package ru.kau.mygtd.interfaces;

import ru.kau.mygtd.objects.Priority;

public interface DialogPriorityChoice {

    public void getPriority(Priority priority);

}
