package ru.kau.mygtd.interfaces;

public interface ResultResponse<T> {
    public boolean onResultRecive(T result);
}
