package ru.kau.mygtd.interfaces;

public interface DialogDateBeginChoice {

    public void getDateBegin(String date, long datemls);

}
