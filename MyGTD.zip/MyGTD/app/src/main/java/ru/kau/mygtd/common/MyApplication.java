package ru.kau.mygtd.common;

import android.app.Application;

import androidx.room.Room;

import ru.kau.mygtd.db.AppDatabase;
import ru.kau.mygtd.db.DbCreator;

//import android.arch.persistence.room.Room;

public class MyApplication extends Application {

    public static MyApplication instance;

    private static AppDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        database = Room.databaseBuilder(this, AppDatabase.class, "MyGTD")
                .allowMainThreadQueries()
                .build();
        DbCreator.firstInit();
    }

    public static MyApplication getInstance() {
        return instance;
    }

    public static AppDatabase getDatabase() {
        return database;
    }
}
