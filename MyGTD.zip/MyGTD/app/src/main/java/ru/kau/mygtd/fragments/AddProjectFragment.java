package ru.kau.mygtd.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.multilevel.treelist.Node;

import java.util.Objects;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.common.enums.PrStatus;
import ru.kau.mygtd.dialogs.Dialogs;
import ru.kau.mygtd.interfaces.DialogProjectChoice;
import ru.kau.mygtd.objects.Project;

public class AddProjectFragment extends Fragment implements DialogProjectChoice {

    private TextView parentProjectTitle;
    private long parentProjectId = 0L;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.addproject_fragment, null);

        final TextView txtProjectTitle = (TextView)rootView.findViewById(R.id.inputProjectTitle);
        final TextView txtProjectInfoTitle = (TextView)rootView.findViewById(R.id.inputProjectinfoTitle);

        Bundle arguments = getArguments();
        Project parentProject = null;

        if (arguments != null && arguments.containsKey("project")) {

            parentProject = (Project) arguments.getSerializable("project");

            parentProjectTitle = (TextView) rootView.findViewById(R.id.parentProject);
            txtProjectTitle.setText(parentProject.getTitle());
            txtProjectInfoTitle.setText(parentProject.getDescription());
            parentProjectTitle.setText(MyApplication.getDatabase().projectDao().getProjectById(parentProject.getParentid()).getTitle());
        }

        final ImageView projectchoise = (ImageView) rootView.findViewById(R.id.parentprojectchoise);

        projectchoise.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Dialogs.choiseProjectDialog(getActivity(), new Runnable() {

                    @Override
                    public void run() {
                        //tagsRunnable.run();
                        //EventBus.getDefault().post(new NotifyAllFragments());
                    }
                });
            }
        });

        ImageButton imgbtnsaveproject = (ImageButton) rootView.findViewById(R.id.btnsaveproject);
        Project finalParentProject = parentProject;
        imgbtnsaveproject.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Project project = new Project();
                project.setTitle(txtProjectTitle.getText().toString());
                project.setSearchtitle(project.getTitle().toUpperCase());
                project.setDescription(txtProjectInfoTitle.getText().toString());
                project.setParentid(finalParentProject.getId());
                project.setPrStatus(PrStatus.ACTIVE);
                MyApplication.getDatabase().projectDao().insert(project);

                closeFragment();
                FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.popBackStack();
            }
        }
        );





        return rootView;
    }

    @Override
    public void getProject(Node node) {
        parentProjectTitle.setText(node.getName());
        parentProjectId = ((Long)node.getId()).longValue();
        //Log.e("444444444", node.getName());
    }

    private void closeFragment(){
        Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().remove(this).commit();
    }
}
