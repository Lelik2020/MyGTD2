package ru.kau.mygtd.utils.task;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import ru.kau.mygtd.R;
import ru.kau.mygtd.dialogs.MyProgressDialog;
import ru.kau.mygtd.utils.LOG;

public abstract class AsyncProgressTask<T> extends AsyncTask<Object, Object, T> {

    ProgressDialog dialog;

    public abstract Context getContext();


    @Override
    protected void onPreExecute() {
        dialog = MyProgressDialog.show(getContext(),  getContext().getString(R.string.please_wait));
    }

    @Override
    protected void onPostExecute(T result) {
        try {
            dialog.dismiss();
        } catch (Exception e) {
            LOG.d(e);
        }

    }

}
