package ru.kau.mygtd.utils.msg;

public class MessageSyncUpdateList {

}
