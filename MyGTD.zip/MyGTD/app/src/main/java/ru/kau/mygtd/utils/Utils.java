package ru.kau.mygtd.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.widget.ImageView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.enums.TypeOfTask;

public class Utils {

    static final public String DEFAULT_TASKSTATUS_COLOR = "#FFA500";
    static final public String DEFAULT_TASKPRIORITY_COLOR = "#FFA500";
    static final public String DEFAULT_TASKOVERDUE_COLOR = "#FF0000";
    static final public String DEFAULT_TASKTODAY_COLOR = "##FFA500";
    static final public String DEFAULT_TASKTOMORROW_COLOR = "#0000FF";
    static final public String DEFAULT_TASKAFTERTOMORROW_COLOR = "#686868";
    static final public String DEFAULT_COLOR = "#000000";





    public static String dateToString(Date date) {

        return dateToString(null, date);
    }

    public static String dateToString(SimpleDateFormat format, Date date) {
        if (format == null || format.equals("")){
            format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        }

        return date == null ? null : format.format(date);
    }

    public static Date getStartOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) return null;
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DATE);
        calendar.set(year, month, day, 0, 0, 0);
        return calendar.getTime();
    }

    public static Date getEndOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) return null;
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DATE);
        calendar.set(year, month, day, 23, 59, 59);
        return calendar.getTime();
    }

    public Date atEndOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime();
    }

    public Date atStartOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    public static long getDateOfParam(int day, int month, int year, int hours, int minutes, int seconds){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.HOUR_OF_DAY, hours);
        calendar.set(Calendar.MINUTE, minutes);
        calendar.set(Calendar.SECOND, seconds);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime().getTime();
    }

    public static int parseColor(String colorString){
        return parseColor(colorString, DEFAULT_COLOR);
    }

    public static int parseColor(String colorString, String defaultColorString){
        int ret = 0;
        if (colorString == null)

            try {
                ret = Color.parseColor(colorString);
            } catch (Exception e){
                ret = parseColor(DEFAULT_COLOR);
            }
        return ret;

    }

    @SuppressLint("ResourceType")
    public static ImageView getIconTaskType(Context c, TypeOfTask typeOfTask){

        switch (typeOfTask.Value){
            case 1:
                return (ImageView) ((Activity)c).findViewById(R.drawable.epic);
            case 2:
                return (ImageView) ((Activity)c).findViewById(R.drawable.story);
            case 3:
                return (ImageView) ((Activity)c).findViewById(R.drawable.task);
            case 4:
                return (ImageView) ((Activity)c).findViewById(R.drawable.bug);
            case 5:
                return (ImageView) ((Activity)c).findViewById(R.drawable.question);
            default:
                return (ImageView) ((Activity)c).findViewById(R.drawable.task);
        }
        //return (ImageView) ((Activity)c).findViewById(R.drawable.task);
    }

    public static int getImageResourceTaskType(TypeOfTask typeOfTask){

        switch (typeOfTask.Value){
            case 1:
                return R.drawable.epic;
            case 2:
                return R.drawable.story;
            case 3:
                return R.drawable.task;
            case 4:
                return R.drawable.bug;
            case 5:
                return R.drawable.question;
            default:
                return R.drawable.task;
        }
        //return (ImageView) ((Activity)c).findViewById(R.drawable.task);
    }


    public static String getColorByEndDate(Date date){
        int diff = daysBetween(Utils.getStartOfDay(date), Utils.getStartOfDay(new Date()));
        if (diff < 0) {
            return DEFAULT_TASKOVERDUE_COLOR;
        } else {
            if (diff == 0) {
                return DEFAULT_TASKTODAY_COLOR;
            } else {
                if (diff == 1) {
                    return DEFAULT_TASKTOMORROW_COLOR;
                } else {
                    return DEFAULT_TASKAFTERTOMORROW_COLOR;
                }
            }
        }

        //return DEFAULT_TASKAFTERTOMORROW_COLOR;

    }

    public static int daysBetween(Date d1, Date d2){
        if (d1 != null && d2 != null) {
            return (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
        } else {
            return 1000000000;
        }
    }


}
