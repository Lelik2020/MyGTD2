package ru.kau.mygtd.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.apg.mobile.roundtextview.RoundTextView;

import java.util.List;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.interfaces.ResultResponse;
import ru.kau.mygtd.objects.InfoStatus;
import ru.kau.mygtd.objects.Information;
import ru.kau.mygtd.utils.Utils;

//import android.support.annotation.NonNull;
//import android.support.v7.widget.RecyclerView;
//import ru.kau.mygtd.objects.Task;

public class InformationAdapter extends RecyclerView.Adapter<InformationAdapter.ViewHolder>{

    Context c;
    List<Information> lstInformation;

    private ResultResponse<Information> onItemClickListener;

    private ResultResponse<Information> onMenuClickListener;



    public InformationAdapter(Context c, List<Information> lstInformation) {
        this.c = c;
        this.lstInformation = lstInformation;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView title;
        TextView dateCreate;
        ImageView menu;
        RoundTextView roundTextView;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.informationtitle);
            dateCreate = (TextView) itemView.findViewById(R.id.date_create);
            menu = (ImageView) itemView.findViewById(R.id.itemMenu);
            roundTextView = (RoundTextView) itemView.findViewById(R.id.status);

        }
    }

    @NonNull
    @Override
    public InformationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(c).inflate(R.layout.information_cardview,viewGroup,false);

        return new InformationAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull InformationAdapter.ViewHolder viewHolder, int i) {
        final Information information = getItem(i);
        final InfoStatus infoStatus = MyApplication.getDatabase().infoStatusDao().getById(information.getIdstatus());
        viewHolder.title.setText(information.getTitle());
        viewHolder.dateCreate.setText(Utils.dateToString(information.getDateCreate()));
        viewHolder.roundTextView.setText(infoStatus.getTitle());
        viewHolder.roundTextView.setBgColor(Color.parseColor(infoStatus.getColor()));
        bindInformationView(viewHolder, i);
        //viewHolder.dateCreate.setText("88888");
    }

    @Override
    public int getItemCount() {
        return lstInformation.size();
    }

    private Information bindInformationView(final ViewHolder holder, final int position) {

        final Information information = (Information) lstInformation.get(position);

        holder.menu.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (onMenuClickListener != null) {
                    onMenuClickListener.onResultRecive(information);
                }
            }

        });
        return null;
    }

    public void setOnItemClickListener(ResultResponse<Information> onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setOnMenuClickListener(ResultResponse<Information> onMenuClickListener) {
        this.onMenuClickListener = onMenuClickListener;
    }

    public Information getItem(int pos) {
        if (lstInformation == null || lstInformation.isEmpty()) {
            return null;
        }
        if (lstInformation.size() - 1 >= pos) {
            return lstInformation.get(pos);
        } else {
            return lstInformation.get(0);
        }
    }

}
