package ru.kau.mygtd.objects;


import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(tableName = "tasktags",
        primaryKeys = { "idtask", "idtag" },
        indices = {
                @Index(value = {"idtask"}),
                @Index(value = {"idtag"})
        },
        foreignKeys = {
                @ForeignKey(entity = Task.class,
                        parentColumns = "id",
                        childColumns = "idtask"),
                @ForeignKey(entity = Tag.class,
                        parentColumns = "id",
                        childColumns = "idtag")
        })
public class TaskTagJoin {
    private final long idtask;
    private final long idtag;

    public TaskTagJoin(long idtask, long idtag) {
        this.idtask = idtask;
        this.idtag = idtag;
    }

    public long getIdtask() {
        return idtask;
    }

    public long getIdtag() {
        return idtag;
    }
}
