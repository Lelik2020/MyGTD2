package ru.kau.mygtd.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import ru.kau.mygtd.R;
import ru.kau.mygtd.adapters.TasksAdapter;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.listeners.DefaultListeners;
import ru.kau.mygtd.objects.Project;
import ru.kau.mygtd.utils.Utils;

public class TasksFragment extends Fragment {

    private RecyclerView recyclerView;
    private RecyclerView recyclerView2;
    private RecyclerView recyclerView3;
    private RecyclerView recyclerView4;
    private RecyclerView recyclerView5;
    private RecyclerView recyclerView6;
    private RecyclerView recyclerView7;
    private RecyclerView recyclerView8;

    private TextView tv1;
    private TextView tv2;
    private TextView tv3;
    private TextView tv4;
    private TextView tv5;
    private TextView tv6;
    private TextView tv7;
    private TextView tv8;


    private ImageView onSort;
    private ActionBar toolbar;
    //private List<Task> lstTask;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.tasks_fragment, null);

        toolbar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        toolbar.setTitle("Задачи");
        setHasOptionsMenu(true);
        //toolbar.menu  onCreateOptionsMenu

        ImageView onSorting = (ImageView) rootView.findViewById(R.id.onSorting);

        onSort = (ImageView) rootView.findViewById(R.id.onSort);


        //Log.e("ПОЗИЦИЯ", "ПОЗИЦИЯ");
        //TasksAdapter tasksAdapter = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getAllTasks());

        Bundle arguments = getArguments();

        if (arguments != null && arguments.containsKey("all")) {



        }

        if (arguments != null && arguments.containsKey("menunumber")) {
            int menuitem = arguments.getInt("menunumber");
            TasksAdapter tasksAdapter;
            switch (menuitem) {

                case 1:

                    tv1 = (TextView) rootView.findViewById(R.id.tv_overdue_task);
                    tv1.setText(getResources().getString(R.string.overduetask));
                    recyclerView = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_overdue);

                    recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                    Log.e("TIME: ", String.valueOf(new Date().getTime()));
                    TasksAdapter tasksAdapter1 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getOverdueTasksWithoutSubtask(new Date().getTime()));
                    //TasksAdapter tasksAdapter1 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getAllTasksWithoutSubtask());
                    bindAdapter(tasksAdapter1);
                    recyclerView.setAdapter(tasksAdapter1);

                    if (tasksAdapter1.getItemCount() == 0){
                        tv1.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.GONE);
                    }


                    tv2 = (TextView) rootView.findViewById(R.id.tv_today_tasks);
                    tv2.setText(getResources().getString(R.string.maketoday) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()) + ")");
                    recyclerView2 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_today);

                    recyclerView2.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter2 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskByDate(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date())));
                    bindAdapter(tasksAdapter2);
                    recyclerView2.setAdapter(tasksAdapter2);

                    if (tasksAdapter2.getItemCount() == 0){
                        tv2.setVisibility(View.GONE);
                        recyclerView2.setVisibility(View.GONE);
                    }

                    // ------------------------------------------------------------------------------------

                    Calendar calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                    Date tomorrow = calendar.getTime();

                    // ------------------------------------------------------------------------------------

                    tv3 = (TextView) rootView.findViewById(R.id.tv_tomorrow_tasks);
                    tv3.setText(getResources().getString(R.string.maketomorrow) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), tomorrow) + ")");
                    recyclerView3 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_tomorrow);

                    recyclerView3.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter3 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskByDate(tomorrow.getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date())));
                    bindAdapter(tasksAdapter3);
                    recyclerView3.setAdapter(tasksAdapter3);

                    if (tasksAdapter3.getItemCount() == 0){
                        tv3.setVisibility(View.GONE);
                        recyclerView3.setVisibility(View.GONE);
                    }

                    // ------------------------------------------------------------------------------------

                    calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 2);
                    Date d1 = Utils.getStartOfDay(calendar.getTime());

                    //calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 5);
                    Date d2 = Utils.getEndOfDay(calendar.getTime());

                    tv4 = (TextView) rootView.findViewById(R.id.tv_nextsevendays_tasks);
                    tv4.setText(getResources().getString(R.string.makenextweek) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + "-" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d2) + ")");

                    recyclerView4 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_nextsevendays);

                    recyclerView4.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter4 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskByDate(d1.getTime(), d2.getTime()));
                    bindAdapter(tasksAdapter4);
                    recyclerView4.setAdapter(tasksAdapter4);

                    if (tasksAdapter4.getItemCount() == 0){
                        tv4.setVisibility(View.GONE);
                        recyclerView4.setVisibility(View.GONE);
                    }

                    // ------------------------------------------------------------------------------------

                    calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 8);
                    d1 = Utils.getStartOfDay(calendar.getTime());

                    calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 14);
                    d2 = Utils.getEndOfDay(calendar.getTime());

                    tv5 = (TextView) rootView.findViewById(R.id.tv_afterweek_tasks);
                    tv5.setText(getResources().getString(R.string.makeafterweek) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + "-" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d2) + ")");

                    recyclerView5 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_afterweek);

                    recyclerView5.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter5 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskByDate(d1.getTime(), d2.getTime()));
                    bindAdapter(tasksAdapter5);
                    recyclerView5.setAdapter(tasksAdapter5);

                    if (tasksAdapter5.getItemCount() == 0){
                        tv5.setVisibility(View.GONE);
                        recyclerView5.setVisibility(View.GONE);
                    }

                    // ------------------------------------------------------------------------------------

                    calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 15);
                    d1 = Utils.getStartOfDay(calendar.getTime());

                    calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 30);
                    d2 = Utils.getEndOfDay(calendar.getTime());

                    tv6 = (TextView) rootView.findViewById(R.id.tv_aftertwoweek_tasks);
                    tv6.setText(getResources().getString(R.string.makeaftertwoweek) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + "-" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d2) + ")");

                    recyclerView6 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_aftertwoweek);

                    recyclerView6.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter6 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskByDate(d1.getTime(), d2.getTime()));
                    bindAdapter(tasksAdapter6);
                    recyclerView6.setAdapter(tasksAdapter6);

                    if (tasksAdapter6.getItemCount() == 0){
                        tv6.setVisibility(View.GONE);
                        recyclerView6.setVisibility(View.GONE);
                    }

                    // ------------------------------------------------------------------------------------

                    calendar = Calendar.getInstance();
                    //Date today = calendar.getTime();

                    calendar.add(Calendar.DAY_OF_YEAR, 31);
                    d1 = Utils.getStartOfDay(calendar.getTime());



                    tv7 = (TextView) rootView.findViewById(R.id.tv_infuture_tasks);
                    tv7.setText(getResources().getString(R.string.makeinfuture) + " (после " + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + ")");

                    recyclerView7 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_infuture);

                    recyclerView7.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter7 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskInFuture(d1.getTime()));
                    bindAdapter(tasksAdapter7);
                    recyclerView7.setAdapter(tasksAdapter7);

                    if (tasksAdapter7.getItemCount() == 0){
                        tv7.setVisibility(View.GONE);
                        recyclerView7.setVisibility(View.GONE);
                    }

                    // -------------------------------------------------------------------------------------------


                    tv8 = (TextView) rootView.findViewById(R.id.tv_noenddate_tasks);
                    tv8.setText(getResources().getString(R.string.makenoenddate));

                    recyclerView8 = (RecyclerView) rootView.findViewById(R.id.tasks_recyclerview_noenddate);

                    recyclerView8.setLayoutManager(new LinearLayoutManager(getActivity()));
                    TasksAdapter tasksAdapter8 = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getTasksWithoutSubtaskNoDateEnd());
                    bindAdapter(tasksAdapter8);
                    recyclerView8.setAdapter(tasksAdapter8);

                    if (tasksAdapter8.getItemCount() == 0){
                        tv8.setVisibility(View.GONE);
                        recyclerView8.setVisibility(View.GONE);
                    }



                case 6:
                    tasksAdapter = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getAllByStatus(-1));
            }

            //tasksAdapter = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getAllTasksWithoutSubtask());
        }

        if (arguments != null && arguments.containsKey("project")) {
            TasksAdapter tasksAdapter;
            Project project = (Project) arguments.getSerializable("project");
            tasksAdapter = new TasksAdapter(getActivity(), MyApplication.getDatabase().taskDao().getAllTasksOfProject(project.getId()));
        }


        return rootView;
    }


    public void bindAdapter(TasksAdapter tasksAdapter) {
        DefaultListeners.bindAdapter2(getActivity(), tasksAdapter);
    }

    /*
    @Override
    public void onBackPressed() {

        int count = getActivity().getSupportFragmentManager().getBackStackEntryCount();

        if (count == 0) {
            super.onBackPressed();
            //additional code
        } else {
            getActivity().getSupportFragmentManager().popBackStack();
        }

    }

     */
}
