package ru.kau.mygtd.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.apg.mobile.roundtextview.RoundTextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import ru.kau.mygtd.R;
import ru.kau.mygtd.common.MyApplication;
import ru.kau.mygtd.common.enums.CommonType;
import ru.kau.mygtd.utils.Utils;

public class CommonAdapter extends RecyclerView.Adapter<CommonAdapter.ViewHolder> {

    Context c;
    List<String> lstCommon;
    CommonType commonType;

    public CommonAdapter(Context c, List<String> lstCommon, CommonType commonType) {
        this.c = c;
        this.lstCommon = lstCommon;
        this.commonType = commonType;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(c).inflate(R.layout.common_cardview, parent,false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final String strLine = getItem(position);
        //final InfoStatus infoStatus = MyApplication.getDatabase().infoStatusDao().getById(information.getIdstatus());
        holder.title.setText(strLine);
        long count = 0L;
        long count2 = 0L;
        long count3 = 0L;
        long count4 = 0L;

        if (position == 0) {
            count = MyApplication.getDatabase().taskDao().getCountAllTasks();
            count2 = MyApplication.getDatabase().taskDao().getCountAllActiveTasks();
            count3 = MyApplication.getDatabase().taskDao().getCountByDate(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
            count4 = MyApplication.getDatabase().taskDao().getCountOutstanding(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
        }

        if (position == 1) {
            switch (commonType) {
                case PROJECT:
                    count = MyApplication.getDatabase().taskDao().getCountAllTasksWithoutProject();
                    count2 = MyApplication.getDatabase().taskDao().getCountAllActiveTasksWithoutProject();
                    count3 = MyApplication.getDatabase().taskDao().getCountByDateWithoutProject(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                    count4 = MyApplication.getDatabase().taskDao().getCountOutstandingWithoutProject(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                    break;
                case TAG:
                    count = MyApplication.getDatabase().taskDao().getCountAllTasksWithoutTag();
                    count2 = MyApplication.getDatabase().taskDao().getCountAllActiveTasksWithoutTag();
                    count3 = MyApplication.getDatabase().taskDao().getCountByDateWithoutTag(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                    count4 = MyApplication.getDatabase().taskDao().getCountOutstandingWithoutTag(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                    break;
                case TARGET:
                    count = MyApplication.getDatabase().taskDao().getCountAllTasksWithoutTarget();
                    count2 = MyApplication.getDatabase().taskDao().getCountAllActiveTasksWithoutTarget();
                    count3 = MyApplication.getDatabase().taskDao().getCountByDateWithoutTarget(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                    count4 = MyApplication.getDatabase().taskDao().getCountOutstandingWithoutTarget(new Date().getTime(), Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), new Date()));
                    break;
                case CONTEXT:

            }


        }

        holder.roundTextView.setCorner(16, 0, 0, 16);

        holder.roundTextView.setBgColor(Color.parseColor("#FF0000"));
        holder.roundTextView.setText(" " + Long.toString(count4) + " ");
        holder.roundTextView.setVisibility(View.VISIBLE);

        holder.roundTextView2.setCorner(0, 0, 0, 0);

        holder.roundTextView2.setBgColor(Color.parseColor("#33FF99"));
        holder.roundTextView2.setText(" " + Long.toString(count3) + " ");
        holder.roundTextView2.setVisibility(View.VISIBLE);

        holder.roundTextView3.setCorner(0, 0, 0, 0);

        holder.roundTextView3.setBgColor(Color.parseColor("#aa03A9F4"));
        holder.roundTextView3.setText(" " + Long.toString(count2) + " ");
        holder.roundTextView3.setVisibility(View.VISIBLE);

        holder.roundTextView4.setCorner(0, 16, 16, 0);

        holder.roundTextView4.setBgColor(Color.parseColor("#808080"));
        holder.roundTextView4.setText(" " + Long.toString(count) + " ");
        holder.roundTextView4.setVisibility(View.VISIBLE);

        bindStringView(holder, position);
    }

    private String bindStringView(final ViewHolder holder, final int position) {

        final String strLine = (String) lstCommon.get(position);

        /*
        holder.menu.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (onMenuClickListener != null) {
                    onMenuClickListener.onResultRecive(information);
                }
            }

        });
        */
        return null;
    }


    @Override
    public int getItemCount() {
        return lstCommon.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView title;
        RoundTextView roundTextView;
        RoundTextView roundTextView2;
        RoundTextView roundTextView3;
        RoundTextView roundTextView4;




        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.commontitle);
            roundTextView = (RoundTextView) itemView.findViewById(R.id.count1);
            roundTextView2 = (RoundTextView) itemView.findViewById(R.id.count2);
            roundTextView3 = (RoundTextView) itemView.findViewById(R.id.count3);
            roundTextView4 = (RoundTextView) itemView.findViewById(R.id.count4);

        }
    }

    public String getItem(int pos) {
        if (lstCommon == null || lstCommon.isEmpty()) {
            return null;
        }
        if (lstCommon.size() - 1 >= pos) {
            return lstCommon.get(pos);
        } else {
            return lstCommon.get(0);
        }
    }
}
