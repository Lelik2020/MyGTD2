package ru.kau.mygtd.common.enums;

public enum DialogType {

    DELETE_TAG,
    DELETE_CONTEXT

}
