package ru.kau.mygtd.objects;


import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(tableName = "infoproject",
        primaryKeys = { "idinformation", "idproject" },
        indices = {
                @Index(value = {"idinformation"}),
                @Index(value = {"idproject"})
        },
        foreignKeys = {
                @ForeignKey(entity = Information.class,
                        parentColumns = "id",
                        childColumns = "idinformation"),
                @ForeignKey(entity = Project.class,
                        parentColumns = "id",
                        childColumns = "idproject")
        }
        )
public class InfoProjectJoin {

    private final long idinformation;
    private final long idproject;

    public InfoProjectJoin(long idinformation, long idproject) {
        this.idinformation = idinformation;
        this.idproject = idproject;
    }

    public long getIdinformation() {
        return idinformation;
    }

    public long getIdproject() {
        return idproject;
    }
}
