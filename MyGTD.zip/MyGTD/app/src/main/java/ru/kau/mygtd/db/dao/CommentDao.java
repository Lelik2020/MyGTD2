package ru.kau.mygtd.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import ru.kau.mygtd.objects.Comment;

@Dao
public interface CommentDao {

    @Query("SELECT * FROM comments")
    List<Comment> getAll();

    @Query("SELECT * FROM comments WHERE task_id = :task_id ORDER BY dateCreate")
    List<Comment> getAllOfTask(long task_id);

    //@Insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Comment comment);

    @Update
    void update(Comment comment);

    @Delete
    void delete(Comment comment);

}
