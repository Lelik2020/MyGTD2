package ru.kau.mygtd.interfaces;

import ru.kau.mygtd.objects.TaskTypes;

public interface DialogTypeOfTaskChoice {

    public void getTypeOfTask(TaskTypes tasktype);

}
