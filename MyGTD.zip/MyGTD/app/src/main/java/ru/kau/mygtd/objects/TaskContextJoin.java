package ru.kau.mygtd.objects;


import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;

@Entity(tableName = "taskcontexts",
        primaryKeys = { "idtask", "idcontext" },
        indices = {
                @Index(value = {"idtask"}),
                @Index(value = {"idcontext"})
        },
        foreignKeys = {
                @ForeignKey(entity = Task.class,
                        parentColumns = "id",
                        childColumns = "idtask"),
                @ForeignKey(entity = Contekst.class,
                        parentColumns = "id",
                        childColumns = "idcontext")
        })
public class TaskContextJoin {
    private final long idtask;
    private final long idcontext;

    public TaskContextJoin(long idtask, long idcontext) {
        this.idtask = idtask;
        this.idcontext = idcontext;
    }

    public long getIdtask() {
        return idtask;
    }

    public long getIdcontext() {
        return idcontext;
    }
}
