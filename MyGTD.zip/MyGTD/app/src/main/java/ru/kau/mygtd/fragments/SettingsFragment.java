package ru.kau.mygtd.fragments;

import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {
}
