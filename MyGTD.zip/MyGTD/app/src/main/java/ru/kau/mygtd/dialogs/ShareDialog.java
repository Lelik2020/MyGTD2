package ru.kau.mygtd.dialogs;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.FragmentManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import ru.kau.mygtd.R;
import ru.kau.mygtd.activities.MainActivity;
import ru.kau.mygtd.fragments.AddProjectFragment;
import ru.kau.mygtd.fragments.AddTaskFragment;
import ru.kau.mygtd.objects.Information;
import ru.kau.mygtd.objects.Project;
import ru.kau.mygtd.objects.Task;
import ru.kau.mygtd.utils.info.wrapper.DocumentController;

public class ShareDialog {



    public static void show(final Activity a, final Runnable onDeleteAction, final Information information) {
        List<String> items = new ArrayList<String>();
        //Log.e("333333333333", "44444444444");
        items.add(a.getString(R.string.add_task));
        items.add(a.getString(R.string.to_archive));
        //items.add(a.getString(R.string.export_bookmarks));
        final AlertDialog.Builder builder = new AlertDialog.Builder(a);
        builder.setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                //int i = 0;
                //Log.e("8888888888", Integer.toString(which));
                switch (which){
                    case 0:
                        AddTaskFragment addTaskFragment = new AddTaskFragment();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("information", information);
                        addTaskFragment.setArguments(bundle);
                        FragmentManager fragmentManager = ((MainActivity)a).getSupportFragmentManager();
                        fragmentManager.beginTransaction().addToBackStack("AddTaskFragment").replace(R.id.frame_container,addTaskFragment).commit();


                }

            }
        });
        AlertDialog create = builder.create();
        /*
        create.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {
                Keyboards.hideNavigation(a);
            }
        });
        */
        create.show();
    }

    public static void show2(final Activity a, final Runnable onDeleteAction, final Task task) {
        List<String> items = new ArrayList<String>();
        //Log.e("333333333333", "44444444444");

        items.add(a.getString(R.string.addsubtask));
        items.add(a.getString(R.string.logworking));
        items.add(a.getString(R.string.add_comment));

        final AlertDialog.Builder builder = new AlertDialog.Builder(a);
        builder.setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {

                switch (which){
                    case 0:
                        AddTaskFragment addTaskFragment = new AddTaskFragment();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("task", task);
                        addTaskFragment.setArguments(bundle);
                        FragmentManager fragmentManager = ((MainActivity)a).getSupportFragmentManager();
                        fragmentManager.beginTransaction().addToBackStack("AddTaskFragment").replace(R.id.frame_container,addTaskFragment).commit();
                    case 2:
                        Dialogs.addCommentDialog(a, null, task, null);
                }

            }
        });
        AlertDialog create = builder.create();

        create.show();

    }

    public static void show3(final Activity a, final Runnable onDeleteAction, final Project project) {
        List<String> items = new ArrayList<String>();
        //Log.e("333333333333", "44444444444");
        items.add(a.getString(R.string.addproject));
        items.add(a.getString(R.string.editproject));
        items.add(a.getString(R.string.add_task));

        final AlertDialog.Builder builder = new AlertDialog.Builder(a);
        builder.setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {

                if (which == 0){

                }

                switch (which){

                    case 0:
                        ((MainActivity)a).getFab().setVisibility(View.INVISIBLE);
                        AddProjectFragment addProjectFragment = new AddProjectFragment();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("project", project);
                        addProjectFragment.setArguments(bundle);
                        FragmentManager fragmentManager = ((MainActivity)a).getSupportFragmentManager();
                        fragmentManager.beginTransaction().addToBackStack("AddProjectFragment").replace(R.id.frame_container,addProjectFragment).commit();
                        break;


                    case 1:
                        ((MainActivity)a).getFab().setVisibility(View.INVISIBLE);
                        addProjectFragment = new AddProjectFragment();
                        bundle = new Bundle();
                        bundle.putSerializable("project", project);
                        addProjectFragment.setArguments(bundle);
                        fragmentManager = ((MainActivity)a).getSupportFragmentManager();
                        fragmentManager.beginTransaction().addToBackStack("AddProjectFragment").replace(R.id.frame_container,addProjectFragment).commit();
                        return;

                    case 2:
                        ((MainActivity)a).getFab().setVisibility(View.INVISIBLE);
                        AddTaskFragment addTaskFragment = new AddTaskFragment();
                        bundle = new Bundle();
                        bundle.putSerializable("project", project);
                        addTaskFragment.setArguments(bundle);
                        fragmentManager = ((MainActivity)a).getSupportFragmentManager();
                        fragmentManager.beginTransaction().addToBackStack("AddTaskFragment").replace(R.id.frame_container,addTaskFragment).commit();
                        return;


                }

            }
        });
        AlertDialog create = builder.create();

        create.show();

    }

    /*public static void show(final Activity a, final File file, final Runnable onDeleteAction, final int page, final DocumentController dc, final Runnable hideShow) {
        if (file == null) {
            Toast.makeText(a, R.string.file_not_found, Toast.LENGTH_LONG).show();
            return;
        }

        if (!ExtUtils.isExteralSD(file.getPath()) && ExtUtils.isNotValidFile(file)) {
            Toast.makeText(a, R.string.file_not_found, Toast.LENGTH_LONG).show();
            return;
        }
        final boolean isPDF = BookType.PDF.is(file.getPath());
        final boolean isLibrary = false;// a instanceof MainTabs2 ? false :
        // true;
        //final boolean isMainTabs = a instanceof MainTabs2;

        List<String> items = new ArrayList<String>();

        if (isLibrary) {
            items.add(a.getString(R.string.library));
        }

        if (dc != null) {
            if (a instanceof VerticalViewActivity || dc.isMusicianMode()) {
                items.add(AppState.get().nameHorizontalMode);
            }
            if (a instanceof HorizontalViewActivity || dc.isMusicianMode()) {
                items.add(AppState.get().nameVerticalMode);
            }

            if (dc.isMusicianMode() == false) {
                items.add(AppState.get().nameMusicianMode);
            }
        }

        if (isPDF) {
            items.add(a.getString(R.string.make_text_reflow));
        }

        if (dc != null) {
            items.add(a.getString(R.string.fast_reading));
        }

        items.add(a.getString(R.string.open_with));
        items.add(a.getString(R.string.send_file));
        final boolean isExternalOrCloud = ExtUtils.isExteralSD(file.getPath()) || Clouds.isCloud(file.getPath());
        boolean canDelete1 = ExtUtils.isExteralSD(file.getPath()) || Clouds.isCloud(file.getPath()) ? true : file.canWrite();
        final boolean canCopy = !ExtUtils.isExteralSD(file.getPath()) && !Clouds.isCloud(file.getPath());
        final boolean isShowInfo = !ExtUtils.isExteralSD(file.getPath());

        final boolean isRemovedFromLibrary = AppData.get().getAllExcluded().contains(new SimpleMeta(file.getPath()));

        if (file.getPath().contains(AppProfile.PROFILE_PREFIX)) {
            canDelete1 = false;
        }
        final boolean canDelete = canDelete1;

        if (isMainTabs) {
            if (canDelete) {
                items.add(a.getString(R.string.delete));
            }
            if (canCopy) {
                items.add(a.getString(R.string.copy));
            }
            if (!isRemovedFromLibrary) {
                items.add(a.getString(R.string.remove_from_library));
            }
        }

        if (!isExternalOrCloud) {
            items.add(a.getString(R.string.add_tags));
        }

        if (AppsConfig.isCloudsEnable) {
            items.add(a.getString(R.string.upload_to_cloud));
        }
        final boolean isPlaylist = file.getName().endsWith(Playlists.L_PLAYLIST);
        if (!isPlaylist) {
            items.add(a.getString(R.string.add_to_playlist));
        }

        final boolean isSyncronized = Clouds.isLibreraSyncFile(file);
        if (!isSyncronized) {
            items.add(a.getString(R.string.sync_book));
        }

        if(isMainTabs){
            items.add(a.getString(R.string.delete_reading_progress));
        }

        if (isShowInfo) {
            items.add(a.getString(R.string.file_info));
        }

        final AlertDialog.Builder builder = new AlertDialog.Builder(a);
        builder.setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                int i = 0;

                if (isLibrary && which == i++) {
                    a.finish();
                    MainTabs2.startActivity(a, UITab.getCurrentTabIndex(UITab.SearchFragment));
                }

                if (dc != null && (a instanceof HorizontalViewActivity || dc.isMusicianMode()) && which == i++) {
                    dc.onCloseActivityFinal(new Runnable() {

                        @Override
                        public void run() {
                            if (dc.isMusicianMode()) {
                                AppSP.get().readingMode = AppState.READING_MODE_BOOK;
                            } else {
                                AppSP.get().readingMode = AppState.READING_MODE_SCROLL;
                            }
                            ExtUtils.showDocumentWithoutDialog(a, file, a.getIntent().getStringExtra(DocumentController.EXTRA_PLAYLIST));

                        }
                    });

                }
                if (dc != null && (a instanceof VerticalViewActivity || dc.isMusicianMode()) && which == i++) {
                    if (dc != null) {
                        dc.onCloseActivityFinal(new Runnable() {

                            @Override
                            public void run() {
                                if (dc.isMusicianMode()) {
                                    AppSP.get().readingMode = AppState.READING_MODE_SCROLL;
                                } else {
                                    AppSP.get().readingMode = AppState.READING_MODE_BOOK;
                                }
                                ExtUtils.showDocumentWithoutDialog(a, file, a.getIntent().getStringExtra(DocumentController.EXTRA_PLAYLIST));
                            }
                        });
                    }
                }
                if (dc != null && dc.isMusicianMode() == false && which == i++) {
                    dc.onCloseActivityFinal(new Runnable() {

                        @Override
                        public void run() {
                            AppSP.get().readingMode = AppState.READING_MODE_MUSICIAN;
                            ExtUtils.showDocumentWithoutDialog(a, file, a.getIntent().getStringExtra(DocumentController.EXTRA_PLAYLIST));
                        }
                    });
                }
                if (isPDF && which == i++) {
                    ExtUtils.openPDFInTextReflow(a, file, page + 1, dc);
                }
                if (dc != null && which == i++) {
                    if (hideShow != null) {
                        AppState.get().isEditMode = false;
                        hideShow.run();
                    }
                    DialogSpeedRead.show(a, dc);
                } else if (which == i++) {
                    ExtUtils.openWith(a, file);
                } else if (which == i++) {
                    ExtUtils.sendFileTo(a, file);
                } else if (isMainTabs && canDelete && which == i++) {
                    FileInformationDialog.dialogDelete(a, file, onDeleteAction);
                } else if (isMainTabs && canCopy && which == i++) {
                    TempHolder.get().copyFromPath = file.getPath();
                    Toast.makeText(a, R.string.copy, Toast.LENGTH_SHORT).show();
                } else if (isMainTabs && !isRemovedFromLibrary && which == i++) {
                    FileMeta load = AppDB.get().load(file.getPath());
                    if (load != null) {
                        load.setIsSearchBook(false);
                        load.setIsStar(false);
                        load.setTag(null);
                        AppDB.get().update(load);

                        AppData.get().removeFavorite(load);
                        AppData.get().addExclue(load.getPath());

                    }


                    EventBus.getDefault().post(new UpdateAllFragments());
                } else if (!isExternalOrCloud && which == i++) {
                    Dialogs.showTagsDialog(a, file, false, null);
                } else if (AppsConfig.isCloudsEnable && which == i++) {
                    showAddToCloudDialog(a, file);
                } else if (!isPlaylist && which == i++) {
                    DialogsPlaylist.showPlaylistsDialog(a, null, file);
                } else if (!isSyncronized && which == i++) {
                    final File to = new File(AppProfile.SYNC_FOLDER_BOOKS, file.getName());
                    boolean result = IO.copyFile(file, to);
                    if (result && AppSP.get().isEnableSync) {

                        AppDB.get().setIsSearchBook(file.getPath(), false);
                        FileMetaCore.createMetaIfNeed(to.getPath(), true);

                        String tags = TagData.getTags(file.getPath());
                        TagData.saveTags(to.getPath(), tags);

                        boolean isRecent = AppData.contains(AppData.get().getAllRecent(), file.getPath());
                        LOG.d("isRecent", isRecent, file.getPath());

                        if (isRecent) {
                            AppData.get().removeRecent(new FileMeta(file.getPath()));

                            final FileMeta load = AppDB.get().load(file.getPath());
                            if (load != null && load.getIsRecentTime() != null) {
                                AppData.get().addRecent(new SimpleMeta(to.getPath(), load.getIsRecentTime()));
                            } else {
                                AppData.get().addRecent(new SimpleMeta(to.getPath()));
                            }
                        }

                        final List<AppBookmark> bookmarks = BookmarksData.get().getBookmarksByBook(file.getPath());
                        for (AppBookmark appBookmark : bookmarks) {
                            appBookmark.path = MyPath.toRelative(to.getPath());
                            BookmarksData.get().add(appBookmark);
                        }

                        GFile.runSyncService(a);
                    }


                    TempHolder.listHash++;
                    EventBus.getDefault().post(new UpdateAllFragments());

                } else if (isMainTabs && which == i++) {
                    SharedBooks.deleteProgress(file.getPath());
                    EventBus.getDefault().post(new UpdateAllFragments());

                } else if (isShowInfo && which == i++) {
                    FileInformationDialog.showFileInfoDialog(a, file, onDeleteAction);
                }

            }

        });
        AlertDialog create = builder.create();
        create.setOnDismissListener(new OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {
                Keyboards.hideNavigation(a);
            }

        });
        create.show();
//        MyPopupMenu menu = new MyPopupMenu(a, null);
//
//        menu.getMenu(R.drawable.glyphicons_basic_578_share, R.string.share, () -> ExtUtils.openPDFInTextReflow(a, file, page + 1, dc));
//        menu.getMenu(R.drawable.glyphicons_2_book_open, R.string.open_with, () -> ExtUtils.openPDFInTextReflow(a, file, page + 1, dc));
//
//        menu.show();
    }*/

    //public static void show(final Activity a, final Runnable onDeleteAction, final Information information) {
    public static void show(final Activity a, final File file, final Runnable onDeleteAction, final int page, final DocumentController dc, final Runnable hideShow) {
        List<String> items = new ArrayList<String>();
        //Log.e("333333333333", "44444444444");
        items.add(a.getString(R.string.add_task));
        items.add(a.getString(R.string.to_archive));
        //items.add(a.getString(R.string.export_bookmarks));
        final AlertDialog.Builder builder = new AlertDialog.Builder(a);
        builder.setItems(items.toArray(new String[items.size()]), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                //int i = 0;
                //Log.e("8888888888", Integer.toString(which));
                switch (which){
                    case 0:
                        /*AddTaskFragment addTaskFragment = new AddTaskFragment();
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("information", information);
                        addTaskFragment.setArguments(bundle);
                        FragmentManager fragmentManager = ((MainActivity)a).getSupportFragmentManager();
                        fragmentManager.beginTransaction().addToBackStack("AddTaskFragment").replace(R.id.frame_container,addTaskFragment).commit();*/


                }

            }
        });
        AlertDialog create = builder.create();
        /*
        create.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {
                Keyboards.hideNavigation(a);
            }
        });
        */
        create.show();
    }




}
