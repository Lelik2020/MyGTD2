package ru.kau.mygtd.db.dao;

//import android.arch.persistence.room.Dao;

//import android.arch.persistence.room.Delete;

//import android.arch.persistence.room.Insert;

//import android.arch.persistence.room.OnConflictStrategy;

//import android.arch.persistence.room.Query;

//import android.arch.persistence.room.Update;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import ru.kau.mygtd.objects.Task;

@Dao
public interface TaskDao {

    @Query("SELECT * FROM tasks")
    List<Task> getAllTasks();

    @Query("SELECT count(*) FROM tasks")
    long getCountAllTasks();

    @Query("SELECT count(*) FROM tasks WHERE id IN (SELECT idtask FROM tasktags WHERE idtag = :tag_id)")
    long getCountAllTasksByTag(long tag_id);

    @Query("SELECT count(*) FROM tasks WHERE id IN (SELECT idtask FROM taskcontexts WHERE idcontext = :context_id)")
    long getCountAllTasksByContekst(long context_id);

    @Query("SELECT count(*) FROM tasks WHERE target_id = :target_id")
    long getCountAllTasksByTarget(long target_id);

    @Query("SELECT count(*) FROM tasks WHERE project_id NOT IN (SELECT ID FROM projects)")
    long getCountAllTasksWithoutProject();


    @Query("SELECT count(*) FROM tasks WHERE (project_id NOT IN (SELECT ID FROM projects)) AND (status IN (1, 2, 3))")
    long getCountAllActiveTasksWithoutProject();

    @Query("SELECT count(*) FROM tasks WHERE id NOT IN (SELECT idtask FROM tasktags)")
    long getCountAllTasksWithoutTag();

    @Query("SELECT count(*) FROM tasks WHERE id NOT IN (SELECT idtask FROM tasktags) AND (status IN (1, 2, 3))")
    long getCountAllActiveTasksWithoutTag();

    @Query("SELECT count(*) FROM tasks WHERE target_id NOT IN (select ID FROM targets)")
    long getCountAllTasksWithoutTarget();

    @Query("SELECT count(*) FROM tasks WHERE target_id NOT IN (select ID FROM targets) AND (status IN (1, 2, 3))")
    long getCountAllActiveTasksWithoutTarget();

    @Query("SELECT * FROM tasks WHERE id = :id")
    Task getById(long id);

    @Query("SELECT count(*) FROM tasks WHERE status = :idstatus")
    long getCountByStatus(long idstatus);

    @Query("SELECT * FROM tasks WHERE status = :idstatus")
    List<Task> getAllByStatus(long idstatus);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3))")
    long getCountByDate(long dateEnd, String dateEndStr);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3)) AND (id IN (SELECT idtask FROM taskcontexts WHERE idcontext = :context_id))")
    long getCountByDateByContekst(long dateEnd, String dateEndStr, long context_id);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3)) AND (id IN (SELECT idtask FROM tasktags WHERE idtag = :tag_id))")
    long getCountByDateByTag(long dateEnd, String dateEndStr, long tag_id);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3)) AND (target_id = :target_id)")
    long getCountByDateByTarget(long dateEnd, String dateEndStr, long target_id);

    @Query("SELECT count(*) FROM tasks WHERE id NOT IN (SELECT idtask FROM tasktags) AND (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3))")
    long getCountByDateWithoutTag(long dateEnd, String dateEndStr);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3)) AND (project_id NOT IN (SELECT ID FROM projects))")
    long getCountByDateWithoutProject(long dateEnd, String dateEndStr);

    @Query("SELECT count(*) FROM tasks WHERE target_id NOT IN (select ID FROM targets) AND (dateEnd = :dateEnd or dateEndStr = :dateEndStr) AND (status IN (1, 2, 3))")
    long getCountByDateWithoutTarget(long dateEnd, String dateEndStr);

    // Просроченные задачи (количество)
    @Query("SELECT count(*) FROM tasks WHERE (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3)")
    long getCountOutstanding(long dateEnd, String dateEndStr);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3) AND (id IN (SELECT idtask FROM tasktags WHERE idtag = :tag_id))")
    long getCountOutstandingByTag(long dateEnd, String dateEndStr, long tag_id);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3) AND (id IN (SELECT idtask FROM taskcontexts WHERE idcontext = :context_id))")
    long getCountOutstandingByContekst(long dateEnd, String dateEndStr, long context_id);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3) AND (target_id = :target_id)")
    long getCountOutstandingByTarget(long dateEnd, String dateEndStr, long target_id);

    @Query("SELECT count(*) FROM tasks WHERE id NOT IN (SELECT idtask FROM tasktags) AND (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3)")
    long getCountOutstandingWithoutTag(long dateEnd, String dateEndStr);

    @Query("SELECT count(*) FROM tasks WHERE (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3) AND (project_id NOT IN (SELECT ID FROM projects))")
    long getCountOutstandingWithoutProject(long dateEnd, String dateEndStr);

    @Query("SELECT count(*) FROM tasks WHERE target_id NOT IN (select ID FROM targets) AND (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3)")
    long getCountOutstandingWithoutTarget(long dateEnd, String dateEndStr);

    // Общее количество незакрытых и неотложенных задач (активных задач)
    @Query("SELECT count(*) FROM tasks WHERE status in (1, 2, 3)")
    long getCountAllActiveTasks();

    @Query("SELECT count(*) FROM tasks WHERE status in (1, 2, 3) AND (id IN (SELECT idtask FROM tasktags WHERE idtag = :tag_id))")
    long getCountAllActiveTasksByTag(long tag_id);

    @Query("SELECT count(*) FROM tasks WHERE status in (1, 2, 3) AND (id IN (SELECT idtask FROM taskcontexts WHERE idcontext = :context_id))")
    long getCountAllActiveTasksByContekst(long context_id);

    @Query("SELECT count(*) FROM tasks WHERE status in (1, 2, 3) AND (target_id = :target_id)")
    long getCountAllActiveTasksByTarget(long target_id);

    // Количество задач в проекте всего
    @Query("SELECT count(*) FROM tasks WHERE project_id = :idProject")
    long getCountAllTasksOfProject(long idProject);

    @Query("SELECT * FROM tasks WHERE project_id = :idProject")
    List<Task> getAllTasksOfProject(long idProject);

    //@Query("SELECT * FROM tasks WHERE status = -1")
    //List<Task> getSometimeTasks();

    // Количество задач в проекте активных (статусы 1 и 2)
    @Query("SELECT count(*) FROM tasks WHERE project_id = :idProject and status in (1, 2, 3)")
    long getCountAllActiveTasksOfProject(long idProject);

    // Количество задач в проекте, которые надо закончить сегодня
    @Query("SELECT count(*) FROM tasks WHERE project_id = :idProject and (dateEnd = :dateEnd or dateEndStr = :dateEndStr) and status in (1, 2, 3)")
    long getCountAllTasksOfProjectToday(long idProject, long dateEnd, String dateEndStr);

    // Количество задач в проекте, которые просрочены
    @Query("SELECT count(*) FROM tasks WHERE project_id = :idProject and (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3)")
    long getCountAllTasksOfProjectOutstanding(long idProject, long dateEnd, String dateEndStr);

    //@Insert
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(Task task);

    @Update
    void update(Task task);

    @Delete
    void delete(Task task);

    @Query("SELECT * FROM tasks WHERE parenttask_id == null or parenttask_id = 0")
    List<Task> getAllTasksWithoutSubtask();

    @Query("SELECT * FROM tasks WHERE (id not in (select t.parenttask_id from tasks t)) and (dateEnd < :date)")
    List<Task> getOverdueTasksWithoutSubtask(long date);

    @Query("SELECT * FROM tasks WHERE (parenttask_id == null or parenttask_id = 0) and (dateEnd = :dateEnd or dateEndStr = :dateEndStr)")
    List<Task> getTasksWithoutSubtaskByDate(long dateEnd, String dateEndStr);

    @Query("SELECT * FROM tasks WHERE (parenttask_id == null or parenttask_id = 0) and (dateEnd > :dateEnd1) and (dateEnd < :dateEnd2)")
    List<Task> getTasksWithoutSubtaskByDate(long dateEnd1, long dateEnd2);

    @Query("SELECT * FROM tasks WHERE (parenttask_id == null or parenttask_id = 0) and (dateEnd >= :dateEnd1)")
    List<Task> getTasksWithoutSubtaskInFuture(long dateEnd1);

    @Query("SELECT * FROM tasks WHERE (parenttask_id == null or parenttask_id = 0) and (dateEnd is null)")
    List<Task> getTasksWithoutSubtaskNoDateEnd();

    @Query("SELECT * FROM tasks WHERE parenttask_id = :parenttask_id")
    List<Task> getSubTasksByParent(long parenttask_id);

    @Query("SELECT count(*) FROM tasks WHERE parenttask_id = :parenttask_id")
    long getCountSubTasksByParent(long parenttask_id);

    // Задачи для пункта "Избранные"
    // Количество задач в проекте всего
    @Query("SELECT count(*) FROM tasks WHERE isFavourite > 0")
    long getCountAllTasksOfFavourite();

    // Количество задач в проекте активных (статусы 1 и 2)
    @Query("SELECT count(*) FROM tasks WHERE isFavourite > 0 and status in (1, 2, 3)")
    long getCountAllActiveTasksOfFavourite();

    // Количество задач в проекте, которые надо закончить сегодня
    @Query("SELECT count(*) FROM tasks WHERE isFavourite > 0 and (dateEnd = :dateEnd or dateEndStr = :dateEndStr) and status in (1, 2, 3)")
    long getCountAllTasksOfFavouriteToday(long dateEnd, String dateEndStr);

    // Количество задач в проекте, которые просрочены
    @Query("SELECT count(*) FROM tasks WHERE isFavourite > 0 and (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3)")
    long getCountAllTasksOfFavouriteOutstanding(long dateEnd, String dateEndStr);

    // Задачи для пункта "Горячие"
    // Количество задач всего
    @Query("SELECT count(*) FROM tasks WHERE priority_id = 1")
    long getCountAllTasksOfHot();

    // Количество горячих задач активных (статусы 1 и 2)
    @Query("SELECT count(*) FROM tasks WHERE priority_id = 1 and status in (1, 2, 3)")
    long getCountAllActiveTasksOfHot();

    // Количество горящих задач в проекте, которые надо закончить сегодня
    @Query("SELECT count(*) FROM tasks WHERE priority_id = 1 and (dateEnd = :dateEnd or dateEndStr = :dateEndStr) and status in (1, 2, 3)")
    long getCountAllTasksOfHotToday(long dateEnd, String dateEndStr);

    // Количество задач в проекте, которые просрочены
    @Query("SELECT count(*) FROM tasks WHERE priority_id = 1 and (dateEnd < :dateEnd or dateEndStr < :dateEndStr) and status in (1, 2, 3)")
    long getCountAllTasksOfHotOutstanding(long dateEnd, String dateEndStr);

    // Количество закрытых задач всего
    @Query("SELECT count(*) FROM tasks WHERE status in (6)")
    long getCountAllClosedTasks();

}
