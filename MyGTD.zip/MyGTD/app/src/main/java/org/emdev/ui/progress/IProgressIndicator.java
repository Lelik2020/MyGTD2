package org.emdev.ui.progress;

public interface IProgressIndicator {

    void setProgressDialogMessage(int resourceID, Object... args);

}
