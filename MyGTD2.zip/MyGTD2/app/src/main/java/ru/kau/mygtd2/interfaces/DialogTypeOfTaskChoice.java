package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.TaskTypes;

public interface DialogTypeOfTaskChoice {

    public void getTypeOfTask(TaskTypes tasktype);

}
