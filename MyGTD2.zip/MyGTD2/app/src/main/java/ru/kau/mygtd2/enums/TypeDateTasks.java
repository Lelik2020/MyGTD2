package ru.kau.mygtd2.enums;

public enum TypeDateTasks {

    OVERDUE,
    TODOTODAY,
    TODOTOMORROW,
    TODONEXTSEVENDAYS,
    TODOAFTERWEEK,
    TODOAFTERTWOWEEK,
    TODOINFUTURE,
    TODONOENDDATE,
    CLOSED

}
