package ru.kau.mygtd2.common.enums;

public enum DialogType {

    DELETE_TAG,
    DELETE_CONTEXT

}
