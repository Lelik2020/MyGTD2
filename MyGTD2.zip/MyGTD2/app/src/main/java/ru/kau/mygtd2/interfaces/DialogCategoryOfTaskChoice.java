package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.TaskCategory;

public interface DialogCategoryOfTaskChoice {


    public void getTaskCategory(TaskCategory taskCategory);

}
