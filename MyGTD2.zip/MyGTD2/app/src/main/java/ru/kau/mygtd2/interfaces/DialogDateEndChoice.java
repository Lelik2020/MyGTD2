package ru.kau.mygtd2.interfaces;

public interface DialogDateEndChoice {

    public void getDateEnd(String date, long datemls);

}
