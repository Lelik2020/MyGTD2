package ru.kau.mygtd2.interfaces;

public interface ResultResponse<T> {
    public boolean onResultRecive(T result);
}
