package ru.kau.mygtd2.utils.msg;

public class MessageSyncUpdateList {

}
