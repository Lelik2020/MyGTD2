package ru.kau.mygtd2.utils;

public interface StringResponse {
    public boolean onResultRecive(String string);
}
