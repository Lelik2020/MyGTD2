package ru.kau.mygtd2.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.sqlite.db.SimpleSQLiteQuery;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import ru.kau.mygtd2.R;
import ru.kau.mygtd2.common.MyApplication;
import ru.kau.mygtd2.common.enums.TypeOfInfo;
import ru.kau.mygtd2.common.enums.TypeOfTask;
import ru.kau.mygtd2.enums.TypeDateTasks;
import ru.kau.mygtd2.objects.Priority;
import ru.kau.mygtd2.objects.Project;
import ru.kau.mygtd2.objects.SQLCondition;
import ru.kau.mygtd2.objects.Statistic;
import ru.kau.mygtd2.objects.Task;

import static java.time.temporal.ChronoUnit.DAYS;
import static ru.kau.mygtd2.utils.Const.DEFAULT_COLOR;
import static ru.kau.mygtd2.utils.Const.DEFAULT_DATEFORMAT;
import static ru.kau.mygtd2.utils.Const.DEFAULT_DATEFORMAT_WITHSECONDS;
import static ru.kau.mygtd2.utils.Const.DEFAULT_TASKAFTERTOMORROW_COLOR;
import static ru.kau.mygtd2.utils.Const.DEFAULT_TASKOVERDUE_COLOR;
import static ru.kau.mygtd2.utils.Const.DEFAULT_TASKTODAY_COLOR;
import static ru.kau.mygtd2.utils.Const.DEFAULT_TASKTOMORROW_COLOR;
import static ru.kau.mygtd2.utils.Const.HIERARCHY_TASKS;

public class Utils {



    public static String dateToString(Date date) {

        return dateToString(null, date);
    }



    public static String dateToString(SimpleDateFormat format, Date date) {
        if (format == null || format.equals("")){
            format = DEFAULT_DATEFORMAT_WITHSECONDS;
        }

        return date == null ? "" : format.format(date);
    }

    public static Date getStartOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) return null;
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DATE);
        calendar.set(year, month, day, 0, 0, 0);
        return calendar.getTime();
    }

    public static Date getEndOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        if (date == null) return null;
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DATE);
        calendar.set(year, month, day, 23, 59, 59);
        //calendar.setTime(date);
        //calendar.set(Calendar.HOUR_OF_DAY, 23);
        //calendar.set(Calendar.MINUTE, 59);
        //calendar.set(Calendar.SECOND, 59);
        //calendar.set(Calendar.MILLISECOND, 99999999);
        return calendar.getTime();
    }

    public static Date atEndOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 99999999);

        return calendar.getTime();
    }

    public static Date atStartOfDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    public static long getDateOfParam(int day, int month, int year, int hours, int minutes, int seconds){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.HOUR_OF_DAY, hours);
        calendar.set(Calendar.MINUTE, minutes);
        calendar.set(Calendar.SECOND, seconds);
        calendar.set(Calendar.MILLISECOND, 999);
        return calendar.getTime().getTime();
    }

    public static int parseColor(String colorString){
        return parseColor(colorString, DEFAULT_COLOR);
    }

    public static int parseColor(String colorString, String defaultColorString){
        int ret = 0;
        if (colorString != null) {

            try {
                ret = Color.parseColor(colorString);
            } catch (Exception e) {
                ret = parseColor(defaultColorString);
            }
        } else {
            ret = parseColor(defaultColorString);
        }
        return ret;

    }

    @SuppressLint("ResourceType")
    public static ImageView getIconTaskType(Context c, TypeOfTask typeOfTask){

        switch (typeOfTask.Value){
            case 1:
                return (ImageView) ((Activity)c).findViewById(R.drawable.epic);
            case 2:
                return (ImageView) ((Activity)c).findViewById(R.drawable.story);
            case 3:
                return (ImageView) ((Activity)c).findViewById(R.drawable.task);
            case 4:
                return (ImageView) ((Activity)c).findViewById(R.drawable.bug);
            case 5:
                return (ImageView) ((Activity)c).findViewById(R.drawable.question);
            default:
                return (ImageView) ((Activity)c).findViewById(R.drawable.task);
        }
        //return (ImageView) ((Activity)c).findViewById(R.drawable.task);
    }

    public static int getImageResourceTaskType(TypeOfTask typeOfTask){

        switch (typeOfTask.Value){
            case 1:
                return R.drawable.epic;
            case 2:
                return R.drawable.story;
            case 3:
                return R.drawable.task;
            case 4:
                return R.drawable.bug;
            case 5:
                return R.drawable.question;
            default:
                return R.drawable.task;
        }
        //return (ImageView) ((Activity)c).findViewById(R.drawable.task);
    }

    public static int getImageResourceInfoType(TypeOfInfo typeOfInfo){

        int image = R.drawable.info;

        switch (typeOfInfo){
            case QUESTION:
                image = R.drawable.question2;
                break;
            case IDEA:
                image = R.drawable.idea4;
                break;
            case INFO:
                image = R.drawable.info;
                break;

            default:
                image = R.drawable.info;
        }
        return image;
        //return (ImageView) ((Activity)c).findViewById(R.drawable.task);
    }


    public static String getColorByEndDate(Date date){
        //int diff = daysBetween(Utils.getStartOfDay(date), Utils.getStartOfDay(new Date()));
        long diff = diffInDays(convertToLocalDateViaInstant(getStartOfDay(date)), convertToLocalDateViaInstant(getStartOfDay(new Date())));
        if (diff < 0) {
            return DEFAULT_TASKOVERDUE_COLOR;
        } else {
            if (diff == 0) {
                return DEFAULT_TASKTODAY_COLOR;
            } else {
                if (diff == 1) {
                    return DEFAULT_TASKTOMORROW_COLOR;
                } else {
                    return DEFAULT_TASKAFTERTOMORROW_COLOR;
                }
            }
        }

        //return DEFAULT_TASKAFTERTOMORROW_COLOR;

    }

    public static int getBackgroundByEndDate(Date date){
        long diff = diffInDays(convertToLocalDateViaInstant(getStartOfDay(date)), convertToLocalDateViaInstant(getStartOfDay(new Date())));
        if (diff < 0) {
            return R.drawable.roundrect_1;
        } else {
            if (diff == 0) {
                return R.drawable.roundrect_2;
            } else {
                if (diff == 1) {
                    return R.drawable.roundrect;
                } else {
                    return R.drawable.roundrect_4;
                }
            }
        }
        //return R.drawable.roundrect_4;
    }

    public static LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
        return dateToConvert == null ? null: dateToConvert.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
    }

    public static int daysBetween(Date d1, Date d2){
        if (d1 != null && d2 != null) {
            return (int) ((d1.getTime() - d2.getTime()) / (1000 * 60 * 60 * 24));
        } else {
            return 1000000000;
        }
    }

    public static long diffInDays(LocalDate a, LocalDate b) {
        return (a != null && b != null) ? DAYS.between(b, a) : 1000000000;
    }

    public static int getLevelTask(Task task){
        int level = 0;
        long id = task.getParenttask_id();
        while (id > 0) {
            level ++;
            id = MyApplication.getDatabase().taskDao().getById(id).getParenttask_id();
            Task t1 = MyApplication.getDatabase().taskDao().getById(id);
            if (t1 != null) {
                getLevelTask(t1);
            }
        }

        return level;
    }

    public static Project getProjectByRootTask(Task task){
        Project pr;

        long id = task.getParenttask_id();
        pr = MyApplication.getDatabase().projectDao().getProjectById(MyApplication.getDatabase().taskDao().getById(id).getProject_id());
        while (id > 0) {

            id = MyApplication.getDatabase().taskDao().getById(id).getParenttask_id();
            Task t1 = MyApplication.getDatabase().taskDao().getById(id);

            if (t1 != null) {
                pr = MyApplication.getDatabase().projectDao().getProjectById(t1.getProject_id());
                getLevelTask(t1);
            }
        }

        return pr;
    }

    public static void updateProjectSubTasks(){

    }

    public static int getIconForPriority(Priority priority){

        switch (priority.getId()){
            case 1: return R.drawable.hi_priority;
                    //break;
            case 2: return R.drawable.hi_priority2;
                    //break;
            case 3: return R.drawable.middle_prior;
                    //break;
            case 4: return R.drawable.low_priority;
                    //break;
            case 5: return R.drawable.minus;
                    //break;
            default: return R.drawable.minus;
                     //break;
        }

    }

    public static String getTextHeading(Fragment fr, TypeDateTasks typeHeading, int count){

        String ret = "";

        switch (typeHeading){
            case OVERDUE:
                ret = ret + fr.getResources().getString(R.string.overduetask);
                break;
            case TODOTODAY:
                ret = ret + fr.getResources().getString(R.string.maketoday) + " (" + Utils.dateToString(DEFAULT_DATEFORMAT, new Date()) + ")";
                break;
            case TODOTOMORROW:
                Calendar calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 1);
                Date tomorrow = calendar.getTime();
                ret = ret + fr.getResources().getString(R.string.maketomorrow) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), tomorrow) + ")";
                break;
            case TODONEXTSEVENDAYS:
                calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 2);
                Date d1 = Utils.getStartOfDay(calendar.getTime());

                //calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 5);
                Date d2 = Utils.getEndOfDay(calendar.getTime());
                ret = ret + fr.getResources().getString(R.string.makenextweek) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + "-" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d2) + ")";
                break;
            case TODOAFTERWEEK:
                calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 8);
                d1 = Utils.getStartOfDay(calendar.getTime());

                calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 14);
                d2 = Utils.getEndOfDay(calendar.getTime());
                ret = ret + fr.getResources().getString(R.string.makeafterweek) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + "-" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d2) + ")";
                break;
            case TODOAFTERTWOWEEK:
                calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 15);
                d1 = Utils.getStartOfDay(calendar.getTime());

                calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 30);
                d2 = Utils.getEndOfDay(calendar.getTime());
                ret = ret + fr.getResources().getString(R.string.makeaftertwoweek) + " (" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + "-" + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d2) + ")";
                break;
            case TODOINFUTURE:
                calendar = Calendar.getInstance();
                //Date today = calendar.getTime();

                calendar.add(Calendar.DAY_OF_YEAR, 31);
                d1 = Utils.getStartOfDay(calendar.getTime());
                ret = ret + fr.getResources().getString(R.string.makeinfuture) + " (после " + Utils.dateToString(new SimpleDateFormat("dd.MM.yyyy"), d1) + ")";
                break;
            case TODONOENDDATE:
                ret = ret + fr.getResources().getString(R.string.makenoenddate);
                break;
            case CLOSED:
                ret = ret + fr.getResources().getString(R.string.closedtasks);
                break;
        }
        ret = ret + ".\nКоличество задач: " + count;
        return ret;

    }

    public static byte[] getArrayByte(List<Integer> intArray){
        byte[] ret = new byte[intArray.size()];
        for (int i = 0; i < intArray.size();i++){
            ret[i] = intArray.get(i).byteValue();
        }
        return ret;
    }

    public static String getStringByArrayInteger(List<Integer> intArray){
        String ret = "";
        for (int i = 0; i < intArray.size() - 1;i++){
            ret = ret + intArray.get(i).toString() + ", ";
        }
        ret = ret + intArray.get(intArray.size() - 1).toString();
        return ret;
    }

    public static List<Task> getListTasksBySQL(List<SQLCondition> lstSQLCond, String sqlText2, Object[] args){
        List<Task> lstTask = null;
        String sqlText = HIERARCHY_TASKS;
        if (sqlText2 != null && !sqlText2.equals("")){
            sqlText += " AND " + sqlText2;
        }
        for(int i = 0; i < lstSQLCond.size(); i++){
            if (lstSQLCond.get(i).getCond().trim().equals("=")
                    || lstSQLCond.get(i).getCond().trim().equals("<")
                    || lstSQLCond.get(i).getCond().trim().equals(">")
                    || lstSQLCond.get(i).getCond().trim().equals(">=")
                    || lstSQLCond.get(i).getCond().trim().equals("<=")){
                sqlText += " AND " + lstSQLCond.get(i).getSource1() + " " + lstSQLCond.get(i).getCond().trim() + " " + lstSQLCond.get(i).getSource2();
            } else {
                sqlText += " AND " + lstSQLCond.get(i).getSource1() + " " + lstSQLCond.get(i).getCond().trim() + " (" + lstSQLCond.get(i).getSource2() + ")";
            }
        }
        //System.out.println(sqltext);
        //Log.e("ERROR", sqlText);
        //Log.e("ERROR2", args.toArray().toString());
        lstTask = MyApplication.getDatabase().taskDao().getTasks(new SimpleSQLiteQuery(sqlText, args));

        return lstTask;
    }

    public static long getLastTaskId(){
        long id = MyApplication.getDatabase().taskDao().getMaxId();
        return id + 1;
    }

    public static long getLastInfoId(){
        long id = MyApplication.getDatabase().informationDao().getMaxId();
        return id + 1;
    }

    public static List<String> getListDateBetweenDates(Date d1, Date d2) throws ParseException {
        List<String> lstDates = new ArrayList<String>();
        String strDate1 = dateToString(DEFAULT_DATEFORMAT, d1);
        String strDate2 = dateToString(DEFAULT_DATEFORMAT, d2);
        lstDates.add(strDate1);
        while (!strDate1.equals(strDate2)){
            Calendar cal = Calendar.getInstance();
            cal.setTime( DEFAULT_DATEFORMAT.parse(strDate1));
            cal.add(Calendar.DATE, 1);
            strDate1 = dateToString(DEFAULT_DATEFORMAT, cal.getTime());
            lstDates.add(strDate1);
            Log.e(strDate1, strDate1);
        }

        return lstDates;
    }

    public static int getMaxFromArray(List<Statistic> lstStat){
        int max = 0;
        for(int i = 0; i < lstStat.size();i++){
            if (lstStat.get(i).getCount1() > max){
                max = (int) lstStat.get(i).getCount1();
            }
        }

        return max;
    }

    public static int getMinFromArray(List<Statistic> lstStat){
        int min = 1000000;
        for(int i = 0; i < lstStat.size();i++){
            if (lstStat.get(i).getCount1() < min){
                min = (int) lstStat.get(i).getCount1();
            }
        }

        return min;
    }

    public static double getAvgFromArray(List<Statistic> lstStat){
        double avg = 0;
        for(int i = 0; i < lstStat.size();i++){
            avg += lstStat.get(i).getCount1();
        }

        return avg / (double)lstStat.size();
    }


}
