package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.TaskStatus;

public interface DialogStatusTaskChoice {

    public void getStatusTask(TaskStatus taskStatus);

}
