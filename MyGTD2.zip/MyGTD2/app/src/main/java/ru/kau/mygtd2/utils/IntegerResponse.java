package ru.kau.mygtd2.utils;

public interface IntegerResponse {

    public boolean onResultRecive(int result);

}
