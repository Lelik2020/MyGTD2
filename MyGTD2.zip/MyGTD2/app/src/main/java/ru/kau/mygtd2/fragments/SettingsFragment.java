package ru.kau.mygtd2.fragments;

import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {
}
