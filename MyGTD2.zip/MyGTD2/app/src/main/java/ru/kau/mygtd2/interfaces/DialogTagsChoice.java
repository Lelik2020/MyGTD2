package ru.kau.mygtd2.interfaces;

import java.util.List;

import ru.kau.mygtd2.objects.Tag;

public interface DialogTagsChoice {

    public void getTags(List<Tag> tags);

}
