package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.Task;

public interface DialogParentTaskChoice {

    public void getParentTask(Task task);

}
