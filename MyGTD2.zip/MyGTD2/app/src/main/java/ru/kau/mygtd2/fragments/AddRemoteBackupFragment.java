package ru.kau.mygtd2.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import ru.kau.mygtd2.R;
import ru.kau.mygtd2.activities.MainActivity;
import ru.kau.mygtd2.adapters.BackupItemAdapter;
import ru.kau.mygtd2.common.MyApplication;
import ru.kau.mygtd2.controllers.Controller;
import ru.kau.mygtd2.objects.Backup;
import ru.kau.mygtd2.objects.BackupItem;
import ru.kau.mygtd2.restapi.BackupApi;

public class AddRemoteBackupFragment extends Fragment {

    private static BackupApi calApi;
    TextView tv;
    RecyclerView rv;
    List<BackupItem> lstBakupItem= new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.addremotebackup_fragment, null);
        tv = rootView.findViewById(R.id.txt);
        rv = rootView.findViewById(R.id.main_recyclerview);

        BackupItem backupItem = new BackupItem();
        backupItem.setId(1);
        backupItem.setTitle("Задачи");
        backupItem.setCount1(1);
        backupItem.setCount2(6);
        backupItem.setPercent((float) (100.0 * backupItem.getCount1() / backupItem.getCount2()));

        lstBakupItem.add(backupItem);

        backupItem.setId(2);
        backupItem.setTitle("Информация");
        backupItem.setCount1(1);
        backupItem.setCount2(6);
        backupItem.setPercent((float) (100.0 * backupItem.getCount1() / backupItem.getCount2()));

        lstBakupItem.add(backupItem);

        backupItem.setId(3);
        backupItem.setTitle("Справочники");
        backupItem.setCount1(1);
        backupItem.setCount2(6);
        backupItem.setPercent((float) (100.0 * backupItem.getCount1() / backupItem.getCount2()));

        lstBakupItem.add(backupItem);

        BackupItemAdapter backupsAdapter = new BackupItemAdapter(getActivity(), lstBakupItem);

        rv.setAdapter(backupsAdapter);


        ActionBar toolbar = ((MainActivity) getActivity()).getSupportActionBar();
        Backup backup = new Backup();
        backup.setDeviceguid(MyApplication.getDatabase().deviceDao().getGuidCurrentDevice());

        calApi = Controller.getCalApi();
        Call<Backup> call = calApi.create(backup);

        call.enqueue(new Callback<Backup>() {

            @Override
            public void onResponse(Call<Backup> call, Response<Backup> response) {
                //edittxt2.setText(response.body().getId().toString() + ":  " + response.body().getText());
                tv.setText(response.body().getGuid());
                Toast.makeText(getContext(), "??????????????", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<Backup> call, Throwable t) {
                Log.e("ERROR", t.getMessage());
                Toast.makeText(getContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                Toast.makeText(getContext(), "!!!!!!!!!!", Toast.LENGTH_SHORT).show();
            }
        });





        return rootView;
    }


}
