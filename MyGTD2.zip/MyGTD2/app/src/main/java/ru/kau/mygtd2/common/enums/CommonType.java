package ru.kau.mygtd2.common.enums;

public enum CommonType {

    PROJECT,
    TAG,
    TARGET,
    CONTEXT

}
