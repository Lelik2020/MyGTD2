package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.Priority;

public interface DialogPriorityChoice {

    public void getPriority(Priority priority);

}
