package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.InfoStatus;

public interface DialogStatusOfInfoChoice {

    public void getStatusOfInfo(InfoStatus infoStatus);

}
