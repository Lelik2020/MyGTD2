package ru.kau.mygtd2.interfaces;


import ru.kau.mygtd2.objects.Project;

public interface DialogProjectChoice {

    public void getProject(Project project);

}
