package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.ProjectStatus;

public interface DialogProjectStatusChoice {

    public void getProjectStatus(ProjectStatus projectStatus);

}
