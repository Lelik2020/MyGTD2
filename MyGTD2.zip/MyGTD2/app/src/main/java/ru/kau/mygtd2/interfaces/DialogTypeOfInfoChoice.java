package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.InfoTypes;

public interface DialogTypeOfInfoChoice {

    public void getTypeOfInfo(InfoTypes infotype);

}
