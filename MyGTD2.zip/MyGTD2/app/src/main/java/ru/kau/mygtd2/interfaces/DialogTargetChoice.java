package ru.kau.mygtd2.interfaces;

import ru.kau.mygtd2.objects.Target;

public interface DialogTargetChoice {

    public void getTarget(Target target);

}
