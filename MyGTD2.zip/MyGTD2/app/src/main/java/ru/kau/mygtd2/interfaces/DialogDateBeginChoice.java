package ru.kau.mygtd2.interfaces;

public interface DialogDateBeginChoice {

    public void getDateBegin(String date, long datemls);

}
