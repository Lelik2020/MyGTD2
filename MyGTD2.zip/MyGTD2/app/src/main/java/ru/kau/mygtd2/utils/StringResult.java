package ru.kau.mygtd2.utils;

public interface StringResult {

    void onResult(String result);

}
